from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription(
        [
            Node(
                package="vision",
                executable="armor_debug_view",
                name="armor_debug_view",
                output="screen",
            )
        ]
    )
