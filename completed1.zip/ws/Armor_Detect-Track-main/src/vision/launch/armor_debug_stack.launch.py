from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    use_hik_camera = LaunchConfiguration("use_hik_camera")
    image_topic = LaunchConfiguration("image_topic")
    binary_thres = LaunchConfiguration("binary_thres")
    detect_color = LaunchConfiguration("detect_color")
    use_classifier = LaunchConfiguration("use_classifier")
    classifier_filter = LaunchConfiguration("classifier_filter")
    debug = LaunchConfiguration("debug")

    return LaunchDescription(
        [
            DeclareLaunchArgument("use_hik_camera", default_value="true"),
            DeclareLaunchArgument("image_topic", default_value="/image_raw"),
            DeclareLaunchArgument("binary_thres", default_value="120"),
            DeclareLaunchArgument("detect_color", default_value="0"),
            DeclareLaunchArgument("use_classifier", default_value="true"),
            DeclareLaunchArgument("classifier_filter", default_value="false"),
            DeclareLaunchArgument("debug", default_value="false"),
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource(
                    PathJoinSubstitution(
                        [FindPackageShare("hik_camera"), "launch", "hik_camera.launch.py"]
                    )
                ),
                condition=IfCondition(use_hik_camera),
            ),
            Node(
                package="armor_detector",
                executable="armor_detector_node",
                name="armor_detector",
                output="screen",
                parameters=[
                    {
                        "image_topic": image_topic,
                        "binary_thres": ParameterValue(binary_thres, value_type=int),
                        "detect_color": ParameterValue(detect_color, value_type=int),
                        "use_classifier": ParameterValue(use_classifier, value_type=bool),
                        "classifier_filter": ParameterValue(classifier_filter, value_type=bool),
                        "debug": ParameterValue(debug, value_type=bool),
                    }
                ],
            ),
            Node(
                package="vision",
                executable="armor_debug_view",
                name="armor_debug_view",
                output="screen",
                parameters=[{"image_topic": image_topic}],
            ),
        ]
    )
