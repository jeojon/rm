# vision

OpenCV viewer for the armor detector's external ROS topic interfaces.

It displays:

- the camera image (`/image_raw`)
- the four key points from every `Armor` in `/detector/armors`
- message fields actually transmitted by `/detector/armors`
- `/camera_info`, `/task_mode`, and `/detector/marker` status

Run:

```bash
ros2 run vision armor_debug_view
```

Optional topic remaps:

```bash
ros2 run vision armor_debug_view --ros-args \
  -p image_topic:=/detector/image_roi \
  -p armors_topic:=/detector/armors \
  -p camera_info_topic:=/camera_info \
  -p task_mode_topic:=/task_mode \
  -p marker_topic:=/detector/marker
```

Press `q` in the window to quit.

One-shot camera + detector + viewer launch:

```bash
ros2 launch vision armor_debug_stack.launch.py
```

Useful overrides:

```bash
ros2 launch vision armor_debug_stack.launch.py \
  use_hik_camera:=true \
  image_topic:=/image_raw \
  binary_thres:=120 \
  use_classifier:=true \
  classifier_filter:=false
```
