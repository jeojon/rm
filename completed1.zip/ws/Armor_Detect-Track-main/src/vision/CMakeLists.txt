cmake_minimum_required(VERSION 3.8)
project(vision)

if(CMAKE_COMPILER_IS_GNUCXX OR CMAKE_CXX_COMPILER_ID MATCHES "Clang")
  add_compile_options(-Wall -Wextra -Wpedantic)
endif()

find_package(ament_cmake REQUIRED)
find_package(rclcpp REQUIRED)
find_package(auto_aim_interfaces REQUIRED)
find_package(sensor_msgs REQUIRED)
find_package(std_msgs REQUIRED)
find_package(geometry_msgs REQUIRED)
find_package(visualization_msgs REQUIRED)
find_package(cv_bridge REQUIRED)
find_package(tf2 REQUIRED)
find_package(tf2_ros REQUIRED)
find_package(tf2_geometry_msgs REQUIRED)
find_package(OpenCV REQUIRED COMPONENTS core imgproc highgui)

add_executable(armor_debug_view src/armor_debug_view.cpp)
target_compile_features(armor_debug_view PRIVATE cxx_std_17)
ament_target_dependencies(
  armor_debug_view
  rclcpp
  auto_aim_interfaces
  sensor_msgs
  std_msgs
  geometry_msgs
  visualization_msgs
  cv_bridge
)
target_link_libraries(armor_debug_view ${OpenCV_LIBS})

add_executable(aim_debug_view src/aim_debug_view.cpp)
target_compile_features(aim_debug_view PRIVATE cxx_std_17)
ament_target_dependencies(
  aim_debug_view
  rclcpp
  auto_aim_interfaces
  sensor_msgs
  geometry_msgs
  cv_bridge
  tf2_ros
  tf2_geometry_msgs
)
target_link_libraries(aim_debug_view ${OpenCV_LIBS})

install(TARGETS aim_debug_view armor_debug_view
  DESTINATION lib/${PROJECT_NAME}
)

install(DIRECTORY launch
  DESTINATION share/${PROJECT_NAME}
)

if(BUILD_TESTING)
  find_package(ament_lint_auto REQUIRED)
  set(ament_cmake_copyright_FOUND TRUE)
  set(ament_cmake_cpplint_FOUND TRUE)
  ament_lint_auto_find_test_dependencies()
endif()

ament_package()
