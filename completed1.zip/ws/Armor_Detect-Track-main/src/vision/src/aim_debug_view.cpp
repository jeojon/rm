#include <rclcpp/rclcpp.hpp>

#include "auto_aim_interfaces/msg/aim_command.hpp"
#include "auto_aim_interfaces/msg/armors.hpp"
#include "auto_aim_interfaces/msg/fire_command.hpp"
#include "auto_aim_interfaces/msg/selected_armor.hpp"
#include "auto_aim_interfaces/msg/target.hpp"

#include <cv_bridge/cv_bridge.hpp>
#include <geometry_msgs/msg/point_stamped.hpp>
#include <sensor_msgs/msg/camera_info.hpp>
#include <sensor_msgs/msg/image.hpp>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>
#include <tf2_ros/buffer.h>
#include <tf2_ros/transform_listener.h>

#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>

#include <chrono>
#include <cmath>
#include <functional>
#include <memory>
#include <sstream>
#include <string>

using rclcpp::Node;
using namespace std::chrono_literals;

namespace vision
{

class aim_debug_view : public Node
{
    public:
    aim_debug_view() : Node("aim_debug_view")
    {
        image_topic_ = this->declare_parameter<std::string>("image_topic", "/image_raw");
        camera_info_topic_ =
            this->declare_parameter<std::string>("camera_info_topic", "/camera_info");
        armors_topic_ = this->declare_parameter<std::string>("armors_topic", "/detector/armors");
        target_topic_ = this->declare_parameter<std::string>("target_topic", "/tracker/target");
        selected_topic_ =
            this->declare_parameter<std::string>("selected_topic", "/choose_Armor/selected_armor");
        aim_topic_ = this->declare_parameter<std::string>("aim_topic", "/aim_solver/aim_command");
        fire_topic_ =
            this->declare_parameter<std::string>("fire_topic", "/fire_control/fire_command");
        camera_frame_ = this->declare_parameter<std::string>("camera_frame", "camera_optical_frame");

        tf_buffer_ = std::make_shared<tf2_ros::Buffer>(this->get_clock());
        tf_listener_ = std::make_shared<tf2_ros::TransformListener>(*tf_buffer_);

        image_subscription_ = this->create_subscription<sensor_msgs::msg::Image>(
            image_topic_, rclcpp::SensorDataQoS(),
            std::bind(&aim_debug_view::imageCallback, this, std::placeholders::_1));
        camera_info_subscription_ = this->create_subscription<sensor_msgs::msg::CameraInfo>(
            camera_info_topic_, rclcpp::SensorDataQoS(),
            std::bind(&aim_debug_view::cameraInfoCallback, this, std::placeholders::_1));
        armors_subscription_ = this->create_subscription<auto_aim_interfaces::msg::Armors>(
            armors_topic_, rclcpp::SensorDataQoS(),
            std::bind(&aim_debug_view::armorsCallback, this, std::placeholders::_1));
        target_subscription_ = this->create_subscription<auto_aim_interfaces::msg::Target>(
            target_topic_, rclcpp::SensorDataQoS(),
            std::bind(&aim_debug_view::targetCallback, this, std::placeholders::_1));
        selected_subscription_ =
            this->create_subscription<auto_aim_interfaces::msg::SelectedArmor>(
            selected_topic_, 10,
            std::bind(&aim_debug_view::selectedCallback, this, std::placeholders::_1));
        aim_subscription_ = this->create_subscription<auto_aim_interfaces::msg::AimCommand>(
            aim_topic_, 10,
            std::bind(&aim_debug_view::aimCallback, this, std::placeholders::_1));
        fire_subscription_ = this->create_subscription<auto_aim_interfaces::msg::FireCommand>(
            fire_topic_, 10,
            std::bind(&aim_debug_view::fireCallback, this, std::placeholders::_1));

        cv::namedWindow(window_name_, cv::WINDOW_NORMAL);
        cv::resizeWindow(window_name_, 960, 720);
        timer_ = this->create_wall_timer(
            33ms, std::bind(&aim_debug_view::render, this));

        RCLCPP_INFO(
            this->get_logger(),
            "aim_debug_view started; this node only displays, no ROS output topic");
    }

    ~aim_debug_view() override
    {
        cv::destroyWindow(window_name_);
    }

    private:
    std::string image_topic_;
    std::string camera_info_topic_;
    std::string armors_topic_;
    std::string target_topic_;
    std::string selected_topic_;
    std::string aim_topic_;
    std::string fire_topic_;
    std::string camera_frame_;
    const std::string window_name_{"aim_debug_view"};

    cv::Mat image_;
    sensor_msgs::msg::CameraInfo::SharedPtr camera_info_;
    auto_aim_interfaces::msg::Armors::SharedPtr armors_;
    auto_aim_interfaces::msg::Target::SharedPtr target_;
    auto_aim_interfaces::msg::SelectedArmor::SharedPtr selected_;
    auto_aim_interfaces::msg::AimCommand::SharedPtr aim_;
    auto_aim_interfaces::msg::FireCommand::SharedPtr fire_;

    std::shared_ptr<tf2_ros::Buffer> tf_buffer_;
    std::shared_ptr<tf2_ros::TransformListener> tf_listener_;
    rclcpp::Subscription<sensor_msgs::msg::Image>::SharedPtr image_subscription_;
    rclcpp::Subscription<sensor_msgs::msg::CameraInfo>::SharedPtr camera_info_subscription_;
    rclcpp::Subscription<auto_aim_interfaces::msg::Armors>::SharedPtr armors_subscription_;
    rclcpp::Subscription<auto_aim_interfaces::msg::Target>::SharedPtr target_subscription_;
    rclcpp::Subscription<auto_aim_interfaces::msg::SelectedArmor>::SharedPtr selected_subscription_;
    rclcpp::Subscription<auto_aim_interfaces::msg::AimCommand>::SharedPtr aim_subscription_;
    rclcpp::Subscription<auto_aim_interfaces::msg::FireCommand>::SharedPtr fire_subscription_;
    rclcpp::TimerBase::SharedPtr timer_;

    void imageCallback(const sensor_msgs::msg::Image::SharedPtr message)
    {
        try {
            image_ = cv_bridge::toCvCopy(message, "bgr8")->image;
        } catch (const cv_bridge::Exception & exception) {
            RCLCPP_WARN_THROTTLE(
                this->get_logger(), *this->get_clock(), 2000,
                "image conversion failed: %s", exception.what());
        }
    }

    void cameraInfoCallback(const sensor_msgs::msg::CameraInfo::SharedPtr message)
    {
        camera_info_ = message;
    }

    void armorsCallback(const auto_aim_interfaces::msg::Armors::SharedPtr message)
    {
        armors_ = message;
    }

    void targetCallback(const auto_aim_interfaces::msg::Target::SharedPtr message)
    {
        target_ = message;
    }

    void selectedCallback(const auto_aim_interfaces::msg::SelectedArmor::SharedPtr message)
    {
        selected_ = message;
    }

    void aimCallback(const auto_aim_interfaces::msg::AimCommand::SharedPtr message)
    {
        aim_ = message;
    }

    void fireCallback(const auto_aim_interfaces::msg::FireCommand::SharedPtr message)
    {
        fire_ = message;
    }

    bool projectPoint(
        const geometry_msgs::msg::Point & point,
        const std_msgs::msg::Header & header,
        cv::Point & pixel) const
    {
        if (!camera_info_ || camera_info_->k[0] <= 0.0 || camera_info_->k[4] <= 0.0) {
            return false;
        }

        geometry_msgs::msg::PointStamped input;
        input.header = header;
        input.point = point;

        try {
            const auto camera_point = tf_buffer_->transform(input, camera_frame_);
            if (camera_point.point.z <= 0.0) {
                return false;
            }

            const double u = camera_info_->k[0] * camera_point.point.x /
                camera_point.point.z + camera_info_->k[2];
            const double v = camera_info_->k[4] * camera_point.point.y /
                camera_point.point.z + camera_info_->k[5];

            if (!std::isfinite(u) || !std::isfinite(v)) {
                return false;
            }

            pixel = cv::Point(cvRound(u), cvRound(v));
            return true;
        } catch (const tf2::TransformException &) {
            return false;
        }
    }

    void drawArmors(cv::Mat & canvas) const
    {
        if (!armors_) {
            return;
        }

        for (const auto & armor : armors_->armors) {
            if (armor.kpts.size() < 4) {
                continue;
            }

            const cv::Point p0(cvRound(armor.kpts[0].x), cvRound(armor.kpts[0].y));
            const cv::Point p1(cvRound(armor.kpts[1].x), cvRound(armor.kpts[1].y));
            const cv::Point p2(cvRound(armor.kpts[2].x), cvRound(armor.kpts[2].y));
            const cv::Point p3(cvRound(armor.kpts[3].x), cvRound(armor.kpts[3].y));

            const cv::Scalar color(0, 255, 255);
            cv::line(canvas, p0, p1, color, 2);
            cv::line(canvas, p1, p2, color, 2);
            cv::line(canvas, p2, p3, color, 2);
            cv::line(canvas, p3, p0, color, 2);

            const std::string label = armor.number + " " + armor.type;
            cv::putText(
                canvas, label, p0 + cv::Point(3, -5),
                cv::FONT_HERSHEY_SIMPLEX, 0.5, color, 1);
        }
    }

    void drawText(cv::Mat & canvas, int & y, const std::string & text, const cv::Scalar & color) const
    {
        cv::putText(
            canvas, text, cv::Point(10, y), cv::FONT_HERSHEY_SIMPLEX,
            0.5, color, 1, cv::LINE_AA);
        y += 20;
    }

    void render()
    {
        if (image_.empty()) {
            return;
        }

        cv::Mat canvas = image_.clone();
        drawArmors(canvas);

        if (camera_info_) {
            const cv::Point optical_center(
                cvRound(camera_info_->k[2]), cvRound(camera_info_->k[5]));
            cv::drawMarker(
                canvas, optical_center, cv::Scalar(255, 255, 255),
                cv::MARKER_CROSS, 20, 1);
        }

        if (aim_ && aim_->valid) {
            cv::Point aim_pixel;
            if (projectPoint(aim_->predicted_position, aim_->header, aim_pixel)) {
                cv::circle(canvas, aim_pixel, 6, cv::Scalar(0, 0, 255), 2);
                cv::putText(
                    canvas, "PRED", aim_pixel + cv::Point(8, -8),
                    cv::FONT_HERSHEY_SIMPLEX, 0.5, cv::Scalar(0, 0, 255), 1);
            }
        }

        if (selected_ && selected_->valid) {
            cv::Point selected_pixel;
            if (projectPoint(selected_->pose.position, selected_->header, selected_pixel)) {
                cv::circle(canvas, selected_pixel, 5, cv::Scalar(255, 0, 255), 2);
            }
        }

        int y = 22;
        const cv::Scalar white(255, 255, 255);
        const cv::Scalar green(0, 255, 0);
        const cv::Scalar yellow(0, 255, 255);
        const cv::Scalar red(0, 0, 255);

        if (target_) {
            std::ostringstream target_text;
            target_text << "TRACK " << (target_->tracking ? "YES" : "NO")
                        << " id=" << target_->id
                        << " n=" << target_->armors_num
                        << " v_yaw=" << target_->v_yaw;
            drawText(canvas, y, target_text.str(), target_->tracking ? green : red);
        } else {
            drawText(canvas, y, "TRACK NO TARGET", red);
        }

        if (selected_ && selected_->valid) {
            std::ostringstream selected_text;
            selected_text << "ARMOR index=" << selected_->armor_index
                          << " yaw=" << selected_->predicted_yaw;
            drawText(canvas, y, selected_text.str(), yellow);
        }

        if (aim_ && aim_->valid) {
            std::ostringstream aim_text;
            aim_text << "AIM yaw=" << aim_->yaw
                     << " pitch=" << aim_->pitch
                     << " dist=" << aim_->distance
                     << " t=" << aim_->flight_time;
            drawText(canvas, y, aim_text.str(), white);

            std::ostringstream aim_point;
            aim_point << "PRED xyz=" << aim_->predicted_position.x << ", "
                      << aim_->predicted_position.y << ", "
                      << aim_->predicted_position.z;
            drawText(canvas, y, aim_point.str(), white);
        } else {
            drawText(canvas, y, "AIM INVALID", yellow);
        }

        if (fire_) {
            std::ostringstream fire_text;
            fire_text << "FIRE allowed=" << (fire_->fire_allowed ? "YES" : "NO")
                      << " trigger=" << (fire_->fire_trigger ? "YES" : "NO")
                      << " yerr=" << fire_->yaw_error
                      << " perr=" << fire_->pitch_error;
            drawText(canvas, y, fire_text.str(), fire_->fire_allowed ? green : red);
        } else {
            drawText(canvas, y, "FIRE NO DATA", red);
        }

        cv::imshow(window_name_, canvas);
        cv::waitKey(1);
    }
};

}  // namespace vision

int main(int argc, char ** argv)
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<vision::aim_debug_view>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
