#include <cv_bridge/cv_bridge.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>
#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/camera_info.hpp>
#include <sensor_msgs/msg/image.hpp>
#include <std_msgs/msg/string.hpp>
#include <visualization_msgs/msg/marker_array.hpp>

#include <algorithm>
#include <cmath>
#include <iomanip>
#include <memory>
#include <sstream>
#include <string>
#include <utility>
#include <vector>

#include "auto_aim_interfaces/msg/armors.hpp"

namespace armor_debug_view
{

class ArmorDebugView : public rclcpp::Node
{
public:
  ArmorDebugView()
  : Node("armor_debug_view")
  {
    image_topic_ = declare_parameter<std::string>("image_topic", "/image_raw");
    camera_info_topic_ = declare_parameter<std::string>("camera_info_topic", "/camera_info");
    task_mode_topic_ = declare_parameter<std::string>("task_mode_topic", "/task_mode");
    armors_topic_ = declare_parameter<std::string>("armors_topic", "/detector/armors");
    marker_topic_ = declare_parameter<std::string>("marker_topic", "/detector/marker");

    image_sub_ = create_subscription<sensor_msgs::msg::Image>(
      image_topic_, rclcpp::SensorDataQoS(),
      std::bind(&ArmorDebugView::imageCallback, this, std::placeholders::_1));
    camera_info_sub_ = create_subscription<sensor_msgs::msg::CameraInfo>(
      camera_info_topic_, rclcpp::SensorDataQoS(),
      std::bind(&ArmorDebugView::cameraInfoCallback, this, std::placeholders::_1));
    task_mode_sub_ = create_subscription<std_msgs::msg::String>(
      task_mode_topic_, 10, std::bind(&ArmorDebugView::taskModeCallback, this, std::placeholders::_1));
    armors_sub_ = create_subscription<auto_aim_interfaces::msg::Armors>(
      armors_topic_, rclcpp::SensorDataQoS(),
      std::bind(&ArmorDebugView::armorsCallback, this, std::placeholders::_1));
    marker_sub_ = create_subscription<visualization_msgs::msg::MarkerArray>(
      marker_topic_, 10, std::bind(&ArmorDebugView::markerCallback, this, std::placeholders::_1));

    cv::namedWindow(window_name_, cv::WINDOW_NORMAL);
    cv::resizeWindow(window_name_, 1280, 900);
    timer_ = create_wall_timer(std::chrono::milliseconds(33), std::bind(&ArmorDebugView::render, this));

    RCLCPP_INFO(
      get_logger(),
      "armor_debug_view listening: image=%s camera_info=%s task=%s armors=%s marker=%s",
      image_topic_.c_str(), camera_info_topic_.c_str(), task_mode_topic_.c_str(),
      armors_topic_.c_str(), marker_topic_.c_str());
  }

  ~ArmorDebugView() override
  {
    cv::destroyWindow(window_name_);
  }

private:
  void imageCallback(const sensor_msgs::msg::Image::ConstSharedPtr message)
  {
    try {
      const auto cv_image = cv_bridge::toCvShare(message, "bgr8");
      if (!cv_image || cv_image->image.empty()) {
        return;
      }
      image_ = cv_image->image.clone();
      image_header_ = message->header;
      image_encoding_ = message->encoding;
      has_image_ = true;
    } catch (const cv_bridge::Exception & exception) {
      RCLCPP_WARN_THROTTLE(
        get_logger(), *get_clock(), 2000, "image conversion failed: %s", exception.what());
    }
  }

  void cameraInfoCallback(const sensor_msgs::msg::CameraInfo::ConstSharedPtr message)
  {
    camera_info_ = message;
  }

  void taskModeCallback(const std_msgs::msg::String::ConstSharedPtr message)
  {
    task_mode_ = message->data;
  }

  void armorsCallback(const auto_aim_interfaces::msg::Armors::ConstSharedPtr message)
  {
    armors_ = message;
  }

  void markerCallback(const visualization_msgs::msg::MarkerArray::ConstSharedPtr message)
  {
    markers_ = message;
  }

  static std::string stampText(const builtin_interfaces::msg::Time & stamp)
  {
    std::ostringstream stream;
    stream << stamp.sec << "." << std::setw(9) << std::setfill('0') << stamp.nanosec;
    return stream.str();
  }

  static std::string fixed(double value, int precision = 3)
  {
    std::ostringstream stream;
    stream << std::fixed << std::setprecision(precision) << value;
    return stream.str();
  }

  static cv::Point toPoint(const geometry_msgs::msg::Point & point)
  {
    return {static_cast<int>(std::lround(point.x)), static_cast<int>(std::lround(point.y))};
  }

  void drawArmors(cv::Mat & canvas) const
  {
    if (!armors_) {
      return;
    }

    const cv::Scalar colors[] = {
      cv::Scalar(0, 255, 255),
      cv::Scalar(255, 180, 0),
      cv::Scalar(0, 200, 255),
      cv::Scalar(180, 255, 0),
      cv::Scalar(255, 0, 255),
    };

    int armor_index = 0;
    for (const auto & armor : armors_->armors) {
      const cv::Scalar color = colors[armor_index % (sizeof(colors) / sizeof(colors[0]))];
      if (armor.kpts.size() >= 4) {
        std::vector<cv::Point> polygon;
        polygon.reserve(4);
        for (std::size_t i = 0; i < 4; ++i) {
          polygon.emplace_back(toPoint(armor.kpts[i]));
        }

        std::vector<std::vector<cv::Point>> polygons{polygon};
        cv::polylines(canvas, polygons, true, color, 2, cv::LINE_AA);
        for (std::size_t i = 0; i < polygon.size(); ++i) {
          cv::circle(canvas, polygon[i], 5, color, cv::FILLED, cv::LINE_AA);
          cv::circle(canvas, polygon[i], 7, cv::Scalar(0, 0, 0), 1, cv::LINE_AA);
          cv::putText(
            canvas, "P" + std::to_string(i), polygon[i] + cv::Point(8, -6),
            cv::FONT_HERSHEY_SIMPLEX, 0.55, color, 2, cv::LINE_AA);
        }

        const std::string label = armor.number + " / " + armor.type;
        cv::putText(
          canvas, label, polygon[0] + cv::Point(8, 22), cv::FONT_HERSHEY_SIMPLEX, 0.75,
          cv::Scalar(0, 0, 0), 4, cv::LINE_AA);
        cv::putText(
          canvas, label, polygon[0] + cv::Point(8, 22), cv::FONT_HERSHEY_SIMPLEX, 0.75, color,
          2, cv::LINE_AA);
      }
      ++armor_index;
    }
  }

  void drawInfoPanel(cv::Mat & canvas) const
  {
    using Line = std::pair<std::string, cv::Scalar>;
    std::vector<Line> lines;
    const cv::Scalar white(255, 255, 255);
    const cv::Scalar green(0, 255, 0);
    const cv::Scalar yellow(0, 255, 255);
    const cv::Scalar cyan(255, 255, 0);

    lines.emplace_back("ARMOR DETECTOR EXTERNAL INTERFACE", cyan);

    if (has_image_) {
      std::ostringstream line;
      line << "IMAGE " << image_topic_ << " | " << image_encoding_ << " | "
           << image_.cols << "x" << image_.rows << " | frame=" << image_header_.frame_id
           << " | stamp=" << stampText(image_header_.stamp);
      lines.emplace_back(line.str(), white);
    } else {
      lines.emplace_back("IMAGE " + image_topic_ + " | waiting for image", yellow);
    }

    if (camera_info_) {
      std::ostringstream line;
      line << "CAMERA_INFO " << camera_info_topic_ << " | fx=" << fixed(camera_info_->k[0], 2)
           << " fy=" << fixed(camera_info_->k[4], 2) << " cx=" << fixed(camera_info_->k[2], 2)
           << " cy=" << fixed(camera_info_->k[5], 2) << " | D=" << camera_info_->d.size()
           << " | frame=" << camera_info_->header.frame_id;
      lines.emplace_back(line.str(), white);
    } else {
      lines.emplace_back("CAMERA_INFO " + camera_info_topic_ + " | waiting", yellow);
    }

    lines.emplace_back("TASK_MODE " + task_mode_topic_ + " | data=\"" + task_mode_ + "\"", white);

    if (armors_) {
      std::ostringstream line;
      line << "ARMORS " << armors_topic_ << " | count=" << armors_->armors.size()
           << " | frame=" << armors_->header.frame_id
           << " | stamp=" << stampText(armors_->header.stamp);
      lines.emplace_back(line.str(), green);
    } else {
      lines.emplace_back("ARMORS " + armors_topic_ + " | waiting", yellow);
    }

    if (markers_) {
      std::ostringstream line;
      line << "MARKER " << marker_topic_ << " | markers=" << markers_->markers.size();
      lines.emplace_back(line.str(), white);
      int text_count = 0;
      for (const auto & marker : markers_->markers) {
        if (marker.type == visualization_msgs::msg::Marker::TEXT_VIEW_FACING &&
          !marker.text.empty() && text_count < 4)
        {
          lines.emplace_back("  marker.text=\"" + marker.text + "\"", cyan);
          ++text_count;
        }
      }
    } else {
      lines.emplace_back("MARKER " + marker_topic_ + " | waiting", yellow);
    }

    if (armors_) {
      int index = 0;
      for (const auto & armor : armors_->armors) {
        if (index >= 6) {
          lines.emplace_back("  ... additional armors not shown", yellow);
          break;
        }
        std::ostringstream pose_line;
        pose_line << "ARMOR[" << index << "] number=\"" << armor.number << "\" type=\""
                  << armor.type << "\" dist_to_image_center="
                  << fixed(armor.distance_to_image_center, 2) << " px";
        lines.emplace_back(pose_line.str(), green);

        std::ostringstream xyz;
        xyz << "  pose.position=(" << fixed(armor.pose.position.x) << ", "
            << fixed(armor.pose.position.y) << ", " << fixed(armor.pose.position.z) << ") m";
        lines.emplace_back(xyz.str(), white);

        std::ostringstream quat;
        quat << "  pose.orientation=(" << fixed(armor.pose.orientation.x, 3) << ", "
             << fixed(armor.pose.orientation.y, 3) << ", "
             << fixed(armor.pose.orientation.z, 3) << ", "
             << fixed(armor.pose.orientation.w, 3) << ")";
        lines.emplace_back(quat.str(), white);

        std::ostringstream kpts;
        kpts << "  kpts=";
        for (std::size_t i = 0; i < armor.kpts.size() && i < 4; ++i) {
          if (i != 0) {
            kpts << " ";
          }
          kpts << "P" << i << "(" << std::lround(armor.kpts[i].x) << ","
               << std::lround(armor.kpts[i].y) << ")";
        }
        lines.emplace_back(kpts.str(), cyan);
        ++index;
      }
    }

    const int line_height = 22;
    const int margin = 10;
    const int max_width = std::max(100, canvas.cols - margin * 2);
    const int max_lines = std::max(1, (canvas.rows - margin * 2 - 16) / line_height);
    if (static_cast<int>(lines.size()) > max_lines) {
      lines.resize(static_cast<std::size_t>(max_lines));
    }

    int panel_width = 0;
    for (const auto & line : lines) {
      int baseline = 0;
      const auto size = cv::getTextSize(
        line.first, cv::FONT_HERSHEY_SIMPLEX, 0.52, 1, &baseline);
      panel_width = std::max(panel_width, size.width);
    }
    panel_width = std::min(max_width, panel_width + 18);
    const int panel_height = std::min(
      canvas.rows - margin * 2, static_cast<int>(lines.size()) * line_height + 10);

    const cv::Rect panel_rect(margin, margin, panel_width, panel_height);
    cv::Mat roi = canvas(panel_rect);
    cv::Mat shade(roi.size(), roi.type(), cv::Scalar(0, 0, 0));
    cv::addWeighted(shade, 0.72, roi, 0.28, 0.0, roi);

    int y = margin + 18;
    for (const auto & line : lines) {
      cv::putText(
        canvas, line.first, cv::Point(margin + 8, y), cv::FONT_HERSHEY_SIMPLEX, 0.52,
        line.second, 1, cv::LINE_AA);
      y += line_height;
    }
  }

  void render()
  {
    cv::Mat canvas;
    if (has_image_) {
      canvas = image_.clone();
    } else {
      canvas = cv::Mat(720, 1280, CV_8UC3, cv::Scalar(18, 18, 18));
      cv::putText(
        canvas, "Waiting for camera image: " + image_topic_, cv::Point(30, 55),
        cv::FONT_HERSHEY_SIMPLEX, 0.9, cv::Scalar(0, 255, 255), 2, cv::LINE_AA);
    }

    drawArmors(canvas);
    drawInfoPanel(canvas);
    cv::imshow(window_name_, canvas);
    const int key = cv::waitKey(1) & 0xFF;
    if (key == 'q' || key == 27) {
      rclcpp::shutdown();
    }
  }

  std::string image_topic_;
  std::string camera_info_topic_;
  std::string task_mode_topic_;
  std::string armors_topic_;
  std::string marker_topic_;
  const std::string window_name_{"Armor External Interface Viewer"};

  rclcpp::Subscription<sensor_msgs::msg::Image>::SharedPtr image_sub_;
  rclcpp::Subscription<sensor_msgs::msg::CameraInfo>::SharedPtr camera_info_sub_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr task_mode_sub_;
  rclcpp::Subscription<auto_aim_interfaces::msg::Armors>::SharedPtr armors_sub_;
  rclcpp::Subscription<visualization_msgs::msg::MarkerArray>::SharedPtr marker_sub_;
  rclcpp::TimerBase::SharedPtr timer_;

  cv::Mat image_;
  std_msgs::msg::Header image_header_;
  std::string image_encoding_;
  bool has_image_{false};
  sensor_msgs::msg::CameraInfo::ConstSharedPtr camera_info_;
  std::string task_mode_{"<not received>"};
  auto_aim_interfaces::msg::Armors::ConstSharedPtr armors_;
  visualization_msgs::msg::MarkerArray::ConstSharedPtr markers_;
};

}  // namespace armor_debug_view

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<armor_debug_view::ArmorDebugView>());
  rclcpp::shutdown();
  return 0;
}
