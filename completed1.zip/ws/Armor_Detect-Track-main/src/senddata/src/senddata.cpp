#include "rclcpp/rclcpp.hpp"
#include "auto_aim_interfaces/msg/datainterface.hpp"
#include "RPL.hpp"

#include <array>
#include <cerrno>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <functional>
#include <mutex>
#include <string>

#include <fcntl.h>
#include <poll.h>
#include <termios.h>
#include <unistd.h>

static constexpr const char* SERIAL_DEVICE =
    "/dev/serial/by-id/usb-1a86_USB_Serial-if00-port0";

#pragma pack(push, 1)
// Both directions use the same 14-byte payload and command ID.
struct DatainterfacePacket {
    float vx;
    float vy;
    float w;
    uint8_t fire_allowed;
    uint8_t fire_trigger;
};
#pragma pack(pop)

static_assert(
    sizeof(DatainterfacePacket) == 14,
    "DatainterfacePacket wire size mismatch");

template <>
struct RPL::Meta::PacketTraits<DatainterfacePacket>
    : RPL::Meta::PacketTraitsBase<
          RPL::Meta::PacketTraits<DatainterfacePacket>> {
    static constexpr uint16_t cmd = 0x0200;
    static constexpr size_t size = sizeof(DatainterfacePacket);
};

/*
 * 打开并配置串口：
 * 115200、8 数据位、无校验、1 停止位、无流控、raw 模式。
 *
 * 成功返回文件描述符，失败返回 -1。
 */
static int serial_open_and_configure(const char *device) {
    int fd = ::open(
        device,
        O_RDWR | O_NOCTTY | O_NONBLOCK | O_CLOEXEC);

    if (fd < 0) {
        return -1;
    }

    termios tty{};

    if (::tcgetattr(fd, &tty) != 0) {
        ::close(fd);
        return -1;
    }

    // 禁止回车换行转换、回显、特殊控制字符处理等
    ::cfmakeraw(&tty);

    tty.c_cflag |= CLOCAL | CREAD;

    // 8 位数据
    tty.c_cflag &= ~CSIZE;
    tty.c_cflag |= CS8;

    // 无校验、1 位停止位
    tty.c_cflag &= ~PARENB;
    tty.c_cflag &= ~CSTOPB;

#ifdef CRTSCTS
    // 无硬件流控
    tty.c_cflag &= ~CRTSCTS;
#endif

    // 无软件流控
    tty.c_iflag &= ~(IXON | IXOFF | IXANY);

    tty.c_cc[VMIN] = 0;
    tty.c_cc[VTIME] = 0;

    if (::cfsetispeed(&tty, B115200) != 0 ||
        ::cfsetospeed(&tty, B115200) != 0 ||
        ::tcsetattr(fd, TCSANOW, &tty) != 0) {
        ::close(fd);
        return -1;
    }

    // 清除打开前可能存在的残留数据
    ::tcflush(fd, TCIOFLUSH);

    return fd;
}

/*
 * 指定长度的数据全部写入串口。
 */
static bool serial_send(
    int fd,
    const uint8_t *data,
    size_t size) {

    size_t written = 0;

    while (written < size) {
        const ssize_t result =
            ::write(fd, data + written, size - written);

        if (result > 0) {
            written += static_cast<size_t>(result);
            continue;
        }

        if (result == 0) {
            return false;
        }

        if (errno == EINTR) {
            continue;
        }

        if (errno == EAGAIN || errno == EWOULDBLOCK) {
            pollfd pfd{};
            pfd.fd = fd;
            pfd.events = POLLOUT;

            const int poll_result = ::poll(&pfd, 1, 100);

            if (poll_result > 0 &&
                (pfd.revents & POLLOUT) != 0) {
                continue;
            }

            if (poll_result < 0 && errno == EINTR) {
                continue;
            }
        }

        return false;
    }

    return true;
}

class getnode : public rclcpp::Node {
private:
    struct RxPacketBinding {
        uint16_t command_id;
        size_t payload_size;
        uint32_t last_version{0};
        std::function<void(RxPacketBinding &)> process;
    };

    std::mutex data_mutex_;
    DatainterfacePacket latest_datainterface_packet_{};
    bool has_datainterface_value_{false};
    bool datainterface_pending_{false};
    uint64_t datainterface_generation_{0};

    RPL::Serializer<DatainterfacePacket> serializer_;

    // 接收解析器和发送序列化器分别管理两个方向的数据。
    RPL::Deserializer<DatainterfacePacket> rx_deserializer_;
    RPL::Parser<DatainterfacePacket> rx_parser_{rx_deserializer_};

    std::array<RxPacketBinding, 1> rx_bindings_{
        {
            {
                RPL::Meta::PacketTraits<DatainterfacePacket>::cmd,
                sizeof(DatainterfacePacket),
                0U,
                [this](RxPacketBinding &binding) {
                    const uint32_t version =
                        rx_deserializer_.version<DatainterfacePacket>();

                    if (version == 0U ||
                        version == binding.last_version) {
                        return;
                    }

                    binding.last_version = version;

                    const DatainterfacePacket packet =
                        rx_deserializer_.get<DatainterfacePacket>();

                    auto_aim_interfaces::msg::Datainterface message;
                    message.yaw = packet.vx;
                    message.pitch = packet.vy;
                    message.w = packet.w;
                    datainterface_feedback_pub_->publish(message);
                }
            }
        }
    };

    rclcpp::TimerBase::SharedPtr rx_timer_;
    rclcpp::TimerBase::SharedPtr tx_timer_;

    int serial_fd_{-1};

    rclcpp::Subscription<
        auto_aim_interfaces::msg::Datainterface>::SharedPtr datainterface_sub_;
    rclcpp::Publisher<
        auto_aim_interfaces::msg::Datainterface>::SharedPtr datainterface_feedback_pub_;

    void callback_datainterface(
        const auto_aim_interfaces::msg::Datainterface::SharedPtr data) {

        if (!data) {
            return;
        }

        DatainterfacePacket packet{};
        packet.vx = data->yaw;
        packet.vy = data->pitch;
        packet.fire_allowed = data->fire_allowed ? 1U : 0U;
        packet.fire_trigger = data->fire_trigger ? 1U : 0U;

        {
            std::lock_guard<std::mutex> lock(data_mutex_);

            const bool changed =
                !has_datainterface_value_ ||
                packet.vx != latest_datainterface_packet_.vx ||
                packet.vy != latest_datainterface_packet_.vy ||
                packet.w != latest_datainterface_packet_.w ||
                packet.fire_allowed != latest_datainterface_packet_.fire_allowed ||
                packet.fire_trigger != latest_datainterface_packet_.fire_trigger;

            latest_datainterface_packet_ = packet;
            has_datainterface_value_ = true;

            if (changed) {
                datainterface_pending_ = true;
                ++datainterface_generation_;
            }
        }

        RCLCPP_INFO(
            this->get_logger(),
            "Received Datainterface: vx=%.3f, vy=%.3f, w=%.3f, fire_allowed=%u, fire_trigger=%u",
            packet.vx,
            packet.vy,
            packet.w,
            packet.fire_allowed,
            packet.fire_trigger);
    }

    void process_received_packets() {
        for (auto &binding : rx_bindings_) {
            binding.process(binding);//这里的process其实就是180行的lambda函数，里面调用了rx_deserializer_.get<DatainterfacePacket>()，然后发布消息
        }
    }

    void receive_packets() {
        if (serial_fd_ < 0) {
            return;
        }

        std::array<uint8_t, 256> buffer{};

        for (;;) {
            const ssize_t result =
                ::read(
                    serial_fd_,
                    buffer.data(),
                    buffer.size());

            if (result > 0) {
                auto parse_result = rx_parser_.push_data(
                    buffer.data(),
                    static_cast<size_t>(result));

                if (!parse_result) {
                    RCLCPP_ERROR_THROTTLE(
                        this->get_logger(),
                        *this->get_clock(),
                        2000,
                        "RPL receive failed: %s",
                        parse_result.error().message.c_str());
                    rx_parser_.clear_buffer();
                }

                continue;
            }

            if (result == 0) {
                break;
            }

            if (errno == EINTR) {
                continue;
            }

            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                break;
            }

            RCLCPP_ERROR_THROTTLE(
                this->get_logger(),
                *this->get_clock(),
                2000,
                "Serial receive failed: %s",
                std::strerror(errno));
            break;
        }

        process_received_packets();
    }

    bool send_packet(const DatainterfacePacket &packet) {
        constexpr size_t frame_capacity =
            RPL::Serializer<DatainterfacePacket>::frame_size<
                DatainterfacePacket>();

        std::array<uint8_t, frame_capacity> frame{};

        auto result =
            serializer_.serialize(
                frame.data(),
                frame.size(),
                packet);

        if (!result) {
            RCLCPP_ERROR(
                this->get_logger(),
                "RPL serialize failed: %s",
                result.error().message.c_str());
            return false;
        }

        if (!serial_send(
                serial_fd_,
                frame.data(),
                *result)) {
            RCLCPP_ERROR_THROTTLE(
                this->get_logger(),
                *this->get_clock(),
                2000,
                "Serial send failed: %s",
                std::strerror(errno));
            return false;
        }

        return true;
    }

    void send_pending_packet() {
        if (serial_fd_ < 0) {
            RCLCPP_ERROR_THROTTLE(
                this->get_logger(),
                *this->get_clock(),
                2000,
                "Serial port is not open");
            return;
        }

        DatainterfacePacket packet_snapshot{};
        bool send_datainterface;
        uint64_t datainterface_generation;

        {
            std::lock_guard<std::mutex> lock(data_mutex_);
            send_datainterface = datainterface_pending_;
            packet_snapshot = latest_datainterface_packet_;
            datainterface_generation = datainterface_generation_;
        }

        if (send_datainterface &&
            send_packet(packet_snapshot)) {
            std::lock_guard<std::mutex> lock(data_mutex_);

            // 如果发送期间又收到新数据，保留新的待发送状态。
            if (datainterface_generation_ == datainterface_generation) {
                datainterface_pending_ = false;
            }
        }
    }

public:
    explicit getnode(const std::string &name)
        : Node(name) {

        serial_fd_ = serial_open_and_configure(SERIAL_DEVICE);

        if (serial_fd_ < 0) {
            RCLCPP_ERROR(
                this->get_logger(),
                "Open %s failed: %s",
                SERIAL_DEVICE,
                std::strerror(errno));
        } else {
            RCLCPP_INFO(
                this->get_logger(),
                "Serial %s opened: 115200 8N1",
                SERIAL_DEVICE);
        }

        datainterface_sub_ =
            this->create_subscription<
                auto_aim_interfaces::msg::Datainterface>(
                    "/ultimate",
                    rclcpp::QoS(10),
                    std::bind(
                        &getnode::callback_datainterface,
                        this,
                        std::placeholders::_1));

        datainterface_feedback_pub_ =
            this->create_publisher<auto_aim_interfaces::msg::Datainterface>(
                "datainterface_feedback",
                rclcpp::QoS(10));

        rx_timer_ = this->create_wall_timer(
            std::chrono::milliseconds(1),
            [this]() {
                receive_packets();
            });

        tx_timer_ = this->create_wall_timer(
            std::chrono::milliseconds(10),
            [this]() {
                send_pending_packet();
            });
    }

    ~getnode() noexcept override {
        if (serial_fd_ >= 0) {
            ::close(serial_fd_);
            serial_fd_ = -1;
        }
    }
};

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);

    auto node =
        std::make_shared<getnode>("datainterface_getnode");

    rclcpp::spin(node);

    rclcpp::shutdown();
    return 0;
}
