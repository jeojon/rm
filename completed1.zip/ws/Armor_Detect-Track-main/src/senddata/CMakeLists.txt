cmake_minimum_required(VERSION 3.8)
project(senddata)

if(CMAKE_COMPILER_IS_GNUCXX OR CMAKE_CXX_COMPILER_ID MATCHES "Clang")
  add_compile_options(-Wall -Wextra -Wpedantic)
endif()

find_package(ament_cmake REQUIRED)
find_package(rclcpp REQUIRED)
find_package(auto_aim_interfaces REQUIRED)

add_executable(senddata src/senddata.cpp)

target_include_directories(senddata PRIVATE
  "${CMAKE_CURRENT_SOURCE_DIR}/include"
)

target_compile_features(senddata PRIVATE cxx_std_20)

ament_target_dependencies(senddata
  rclcpp
  auto_aim_interfaces
)

install(TARGETS senddata
  DESTINATION lib/${PROJECT_NAME}
)

if(BUILD_TESTING)
  find_package(ament_lint_auto REQUIRED)
  set(ament_cmake_copyright_FOUND TRUE)
  set(ament_cmake_cpplint_FOUND TRUE)
  ament_lint_auto_find_test_dependencies()
endif()

ament_package()
