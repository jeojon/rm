std_msgs/Header header

bool valid
string target_id
int32 armor_index

geometry_msgs/Point predicted_position

float64 yaw
float64 pitch
float64 distance
float64 flight_time
float64 bullet_speed
