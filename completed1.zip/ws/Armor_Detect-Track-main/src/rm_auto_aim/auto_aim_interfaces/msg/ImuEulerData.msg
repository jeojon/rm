std_msgs/Header header

float32 roll
float32 pitch
float32 yaw

float32 angular_velocity_x
float32 angular_velocity_y
float32 angular_velocity_z

float32 linear_acceleration_x
float32 linear_acceleration_y
float32 linear_acceleration_z
