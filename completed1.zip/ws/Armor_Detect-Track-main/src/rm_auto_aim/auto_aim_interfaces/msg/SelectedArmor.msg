std_msgs/Header header

bool valid
string target_id
int32 armor_index
int32 armors_num

geometry_msgs/Pose pose
float64 predicted_yaw
float64 priority
