std_msgs/Header header

bool valid
bool fire_allowed
bool fire_trigger

string target_id
int32 armor_index

float64 yaw_error
float64 pitch_error
float64 stable_time
float64 aim_command_age
