# 云台角度和火控信息
float32 yaw
float32 pitch
float32 w

bool fire_allowed
bool fire_trigger
