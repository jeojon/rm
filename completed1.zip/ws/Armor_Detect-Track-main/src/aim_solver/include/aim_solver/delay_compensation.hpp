#ifndef AIM_SOLVER__DELAY_COMPENSATION_HPP_
#define AIM_SOLVER__DELAY_COMPENSATION_HPP_

#include <algorithm>
#include <cmath>

namespace aim_solver
{

struct ExternalDelay
{
  double serial_delay{0.0};   // 串口/总线传输延迟
  double gimbal_delay{0.0};   // 云台响应延迟
  double fire_delay{0.0};     // 摩擦轮/发弹延迟
};

inline double computeExternalDelay(const ExternalDelay & delay)
{
  const double serial = std::max(0.0, delay.serial_delay);
  const double gimbal = std::max(0.0, delay.gimbal_delay);
  const double fire = std::max(0.0, delay.fire_delay);
  return serial + gimbal + fire;
}

}  // namespace aim_solver

#endif  // AIM_SOLVER__DELAY_COMPENSATION_HPP_
