#include <rclcpp/rclcpp.hpp>

#include "auto_aim_interfaces/msg/selected_armor.hpp"
#include "auto_aim_interfaces/msg/target.hpp"

#include <geometry_msgs/msg/point_stamped.hpp>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>
#include <tf2_ros/buffer.h>
#include <tf2_ros/transform_listener.h>

#include <algorithm>
#include <cmath>
#include <functional>
#include <limits>
#include <memory>
#include <string>
#include <vector>

using rclcpp::Node;

namespace aim_solver
{

class choose_Armor : public Node
{
    public:
    choose_Armor() : Node("choose_Armor")
    {
        RCLCPP_INFO(this->get_logger(), "装甲板选择节点已经创建!!!");

        target_topic_ = this->declare_parameter<std::string>(
            "target_topic", "/tracker/target");
        output_topic_ = this->declare_parameter<std::string>(
            "output_topic", "/choose_Armor/selected_armor");
        camera_frame_ = this->declare_parameter<std::string>(
            "camera_frame", "camera_optical_frame");

        gyro_threshold_ = this->declare_parameter<double>(
            "gyro_threshold", 1.0);
        diff_angle_ = this->declare_parameter<double>(
            "diff_angle", 0.5);
        switch_margin_ = this->declare_parameter<double>(
            "switch_margin", 0.05);
        prediction_latency_ = this->declare_parameter<double>(
            "prediction_latency", 0.02);

        tf_buffer_ = std::make_shared<tf2_ros::Buffer>(this->get_clock());
        tf_listener_ = std::make_shared<tf2_ros::TransformListener>(*tf_buffer_);

        publisher_ = this->create_publisher<auto_aim_interfaces::msg::SelectedArmor>(
            output_topic_, 10);
        subscription_ = this->create_subscription<auto_aim_interfaces::msg::Target>(
            target_topic_, rclcpp::SensorDataQoS(),
            std::bind(&choose_Armor::targetCallback, this, std::placeholders::_1));

        RCLCPP_INFO(
            this->get_logger(),
            "choose_Armor started: %s -> %s",
            target_topic_.c_str(), output_topic_.c_str());
    }

    private:
    struct Candidate
    {
        int index{-1};
        double x{0.0};
        double y{0.0};
        double z{0.0};
        double yaw{0.0};
        double priority{-std::numeric_limits<double>::infinity()};
        bool valid{false};
    };

    std::string target_topic_;
    std::string output_topic_;
    std::string camera_frame_;

    double gyro_threshold_;
    double diff_angle_;
    double switch_margin_;
    double prediction_latency_;

    bool state_tracking_{false};
    int selected_index_{-1};
    std::string selected_target_id_;

    std::shared_ptr<tf2_ros::Buffer> tf_buffer_;
    std::shared_ptr<tf2_ros::TransformListener> tf_listener_;
    rclcpp::Publisher<auto_aim_interfaces::msg::SelectedArmor>::SharedPtr publisher_;
    rclcpp::Subscription<auto_aim_interfaces::msg::Target>::SharedPtr subscription_;

    static double wrapAngle(double angle)
    {
        return std::atan2(std::sin(angle), std::cos(angle));
    }

    double predictionDt(const auto_aim_interfaces::msg::Target & target) const
    {
        double dt = prediction_latency_;

        if (target.header.stamp.sec != 0 || target.header.stamp.nanosec != 0) {
            const double age = (this->now() - rclcpp::Time(target.header.stamp)).seconds();
            dt += std::max(0.0, age);
        }

        return std::clamp(dt, 0.0, 0.5);
    }

    std::vector<Candidate> makeCandidates(
        const auto_aim_interfaces::msg::Target & target,
        double dt,
        bool & gyro_mode)
    {
        std::vector<Candidate> candidates;
        const int armors_num = std::max(1, target.armors_num);

        const double center_x = target.position.x + target.velocity.x * dt;
        const double center_y = target.position.y + target.velocity.y * dt;
        const double center_z = target.position.z + target.velocity.z * dt;
        const double center_yaw = target.yaw + target.v_yaw * dt;

        gyro_mode = std::abs(target.v_yaw) >= gyro_threshold_;

        for (int i = 0; i < armors_num; ++i) {
            Candidate candidate;
            candidate.index = i;

            const double phase = i * 2.0 * M_PI / static_cast<double>(armors_num);
            candidate.yaw = center_yaw + phase;

            double radius = target.radius_1;
            if (armors_num == 4) {
                radius = (i % 2 == 0) ? target.radius_1 : target.radius_2;
                candidate.z = center_z + ((i % 2 == 0) ? 0.0 : target.dz);
            } else {
                candidate.z = center_z;
            }

            if (!std::isfinite(radius) || radius <= 0.0) {
                continue;
            }

            candidate.x = center_x - radius * std::cos(candidate.yaw);
            candidate.y = center_y - radius * std::sin(candidate.yaw);
            candidate.valid = true;
            candidates.emplace_back(candidate);
        }

        return candidates;
    }

    bool selectByOpticalAxis(
        const auto_aim_interfaces::msg::Target & target,
        std::vector<Candidate> & candidates)
    {
        bool transformed_any = false;

        for (auto & candidate : candidates) {
            if (!candidate.valid) {
                continue;
            }

            geometry_msgs::msg::PointStamped point_in;
            point_in.header = target.header;
            point_in.point.x = candidate.x;
            point_in.point.y = candidate.y;
            point_in.point.z = candidate.z;

            try {
                const auto point_out = tf_buffer_->transform(point_in, camera_frame_);
                if (point_out.point.z <= 0.0) {
                    continue;
                }

                const double angle = std::atan2(
                    std::hypot(point_out.point.x, point_out.point.y),
                    point_out.point.z);
                candidate.priority = -angle;
                transformed_any = true;
            } catch (const tf2::TransformException & ex) {
                RCLCPP_WARN_THROTTLE(
                    this->get_logger(), *this->get_clock(), 2000,
                    "armor candidate TF failed: %s", ex.what());
                return false;
            }
        }

        return transformed_any;
    }

    bool selectByGyro(
        const auto_aim_interfaces::msg::Target & target,
        std::vector<Candidate> & candidates)
    {
        if (target.header.frame_id.empty()) {
            return false;
        }

        double camera_x = 0.0;
        double camera_y = 0.0;
        try {
            const auto camera_in_target = tf_buffer_->lookupTransform(
                target.header.frame_id, camera_frame_, target.header.stamp);
            camera_x = camera_in_target.transform.translation.x;
            camera_y = camera_in_target.transform.translation.y;
        } catch (const tf2::TransformException & ex) {
            RCLCPP_WARN_THROTTLE(
                this->get_logger(), *this->get_clock(), 2000,
                "gimbal center TF failed: %s", ex.what());
            return false;
        }

        const double center_theta = std::atan2(
            target.position.y - camera_y,
            target.position.x - camera_x);
        const double half_diff = diff_angle_ * 0.5;

        bool selected_any = false;
        for (auto & candidate : candidates) {
            if (!candidate.valid) {
                continue;
            }

            const double yaw_diff = wrapAngle(candidate.yaw - center_theta);
            if (std::abs(yaw_diff) >= half_diff) {
                continue;
            }

            candidate.priority = -std::abs(yaw_diff);
            selected_any = true;
        }

        return selected_any;
    }

    int bestCandidate(const std::vector<Candidate> & candidates) const
    {
        int best = -1;
        double best_priority = -std::numeric_limits<double>::infinity();
        for (std::size_t i = 0; i < candidates.size(); ++i) {
            if (!candidates[i].valid) {
                continue;
            }
            if (candidates[i].priority > best_priority) {
                best_priority = candidates[i].priority;
                best = static_cast<int>(i);
            }
        }
        return best;
    }

    void publishInvalid(const auto_aim_interfaces::msg::Target & target)
    {
        auto_aim_interfaces::msg::SelectedArmor output;
        output.header = target.header;
        output.valid = false;
        output.target_id = target.id;
        output.armor_index = -1;
        output.armors_num = target.armors_num;
        publisher_->publish(output);
    }

    void targetCallback(const auto_aim_interfaces::msg::Target::SharedPtr target)
    {
        if (!target->tracking) {
            state_tracking_ = false;
            selected_index_ = -1;
            selected_target_id_.clear();
            publishInvalid(*target);
            return;
        }

        if (target->id != selected_target_id_) {
            state_tracking_ = false;
            selected_index_ = -1;
            selected_target_id_ = target->id;
        }

        const double dt = predictionDt(*target);
        bool gyro_mode = false;
        auto candidates = makeCandidates(*target, dt, gyro_mode);
        if (candidates.empty()) {
            publishInvalid(*target);
            return;
        }

        const bool selection_ok = gyro_mode ?
            selectByGyro(*target, candidates) :
            selectByOpticalAxis(*target, candidates);

        const int best = bestCandidate(candidates);
        if (!selection_ok || best < 0) {
            publishInvalid(*target);
            return;
        }

        int selected = -1;
        if (!state_tracking_ || selected_index_ < 0 ||
            selected_index_ >= static_cast<int>(candidates.size()) ||
            !candidates[static_cast<std::size_t>(selected_index_)].valid) {
            selected = best;
            state_tracking_ = true;
        } else {
            selected = selected_index_;
            if (best != selected &&
                candidates[static_cast<std::size_t>(best)].priority >
                    candidates[static_cast<std::size_t>(selected)].priority + switch_margin_) {
                selected = best;
            }
        }

        selected_index_ = selected;
        const Candidate & result = candidates[static_cast<std::size_t>(selected)];

        auto_aim_interfaces::msg::SelectedArmor output;
        output.header = target->header;
        output.valid = true;
        output.target_id = target->id;
        output.armor_index = result.index;
        output.armors_num = target->armors_num;
        output.pose.position.x = result.x;
        output.pose.position.y = result.y;
        output.pose.position.z = result.z;

        tf2::Quaternion orientation;
        orientation.setRPY(0.0, 0.0, result.yaw);
        output.pose.orientation = tf2::toMsg(orientation);

        output.predicted_yaw = result.yaw;
        output.priority = result.priority;
        publisher_->publish(output);

        RCLCPP_INFO_THROTTLE(
            this->get_logger(), *this->get_clock(), 1000,
            "selected armor: target=%s index=%d mode=%s yaw=%.3f priority=%.3f",
            target->id.c_str(), result.index, gyro_mode ? "gyro" : "translation",
            result.yaw, result.priority);
    }
};

}  // namespace aim_solver

int main(int argc, char ** argv)
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<aim_solver::choose_Armor>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
