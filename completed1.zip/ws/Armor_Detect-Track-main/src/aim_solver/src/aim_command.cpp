#include <rclcpp/rclcpp.hpp>

#include "auto_aim_interfaces/msg/aim_command.hpp"
#include "auto_aim_interfaces/msg/selected_armor.hpp"
#include "auto_aim_interfaces/msg/target.hpp"

#include "aim_solver/delay_compensation.hpp"

#include <tf2/LinearMath/Quaternion.h>
#include <tf2/LinearMath/Vector3.h>
#include <tf2/time.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>
#include <tf2_ros/buffer.h>
#include <tf2_ros/transform_listener.h>

#include <algorithm>
#include <cmath>
#include <functional>
#include <memory>
#include <string>

using rclcpp::Node;

namespace aim_solver
{

class aim_command : public Node
{
    public:
    aim_command() : Node("aim_command")
    {
        selected_topic_ = this->declare_parameter<std::string>(
            "selected_topic", "/choose_Armor/selected_armor");
        target_topic_ = this->declare_parameter<std::string>(
            "target_topic", "/tracker/target");
        output_topic_ = this->declare_parameter<std::string>(
            "output_topic", "/aim_solver/aim_command");
        gimbal_pitch_frame_ = this->declare_parameter<std::string>(
            "gimbal_pitch_frame", "gimbal_pitch");

        // 枪口相对 gimbal_pitch：只有平移，方向与 gimbal_pitch 的 x 轴一致
        muzzle_x_ = this->declare_parameter<double>("muzzle_x", 0.2448);
        muzzle_y_ = this->declare_parameter<double>("muzzle_y", 0.0);
        muzzle_z_ = this->declare_parameter<double>("muzzle_z", 0.11635);

        bullet_speed_ = this->declare_parameter<double>("bullet_speed", 14.0);
        gravity_ = this->declare_parameter<double>("gravity", 9.81);
        max_iterations_ = this->declare_parameter<int>("max_iterations", 5);

        delay_.serial_delay = this->declare_parameter<double>("serial_delay", 0.0);
        delay_.gimbal_delay = this->declare_parameter<double>("gimbal_delay", 0.0);
        delay_.fire_delay = this->declare_parameter<double>("fire_delay", 0.0);
        external_delay_ = computeExternalDelay(delay_);

        tf_buffer_ = std::make_shared<tf2_ros::Buffer>(this->get_clock());
        tf_listener_ = std::make_shared<tf2_ros::TransformListener>(*tf_buffer_);

        publisher_ = this->create_publisher<auto_aim_interfaces::msg::AimCommand>(
            output_topic_, 10);
        selected_subscription_ =
            this->create_subscription<auto_aim_interfaces::msg::SelectedArmor>(
            selected_topic_, 10,
            std::bind(&aim_command::selectedCallback, this, std::placeholders::_1));
        target_subscription_ =
            this->create_subscription<auto_aim_interfaces::msg::Target>(
            target_topic_, rclcpp::SensorDataQoS(),
            std::bind(&aim_command::targetCallback, this, std::placeholders::_1));

        RCLCPP_INFO(
            this->get_logger(),
            "aim_command started: %s + %s -> %s, bullet speed %.2f m/s",
            selected_topic_.c_str(), target_topic_.c_str(), output_topic_.c_str(),
            bullet_speed_);
    }

    private:
    std::string selected_topic_;
    std::string target_topic_;
    std::string output_topic_;
    std::string gimbal_pitch_frame_;

    double muzzle_x_;
    double muzzle_y_;
    double muzzle_z_;
    double bullet_speed_;
    double gravity_;
    int max_iterations_;

    ExternalDelay delay_;
    double external_delay_{0.0};

    auto_aim_interfaces::msg::SelectedArmor::SharedPtr selected_;
    auto_aim_interfaces::msg::Target::SharedPtr target_;

    std::shared_ptr<tf2_ros::Buffer> tf_buffer_;
    std::shared_ptr<tf2_ros::TransformListener> tf_listener_;
    rclcpp::Publisher<auto_aim_interfaces::msg::AimCommand>::SharedPtr publisher_;
    rclcpp::Subscription<auto_aim_interfaces::msg::SelectedArmor>::SharedPtr selected_subscription_;
    rclcpp::Subscription<auto_aim_interfaces::msg::Target>::SharedPtr target_subscription_;

    void selectedCallback(const auto_aim_interfaces::msg::SelectedArmor::SharedPtr message)
    {
        selected_ = message;
        computeAndPublish();
    }

    void targetCallback(const auto_aim_interfaces::msg::Target::SharedPtr message)
    {
        target_ = message;
        computeAndPublish();
    }

    void publishInvalid(
        const std_msgs::msg::Header & source_header,
        const std::string & target_id,
        int armor_index)
    {
        auto_aim_interfaces::msg::AimCommand output;
        output.header = source_header;
        output.header.stamp = this->now();
        output.valid = false;
        output.target_id = target_id;
        output.armor_index = armor_index;
        output.bullet_speed = bullet_speed_;
        publisher_->publish(output);
    }

    bool getMuzzlePosition(
        const std::string & target_frame,
        geometry_msgs::msg::Point & muzzle_position)
    {
        try {
            const auto transform = tf_buffer_->lookupTransform(
                target_frame, gimbal_pitch_frame_, tf2::TimePointZero);

            tf2::Quaternion rotation;
            tf2::fromMsg(transform.transform.rotation, rotation);

            const tf2::Vector3 muzzle_offset(muzzle_x_, muzzle_y_, muzzle_z_);
            const tf2::Vector3 rotated_offset = tf2::quatRotate(rotation, muzzle_offset);

            muzzle_position.x =
                transform.transform.translation.x + rotated_offset.x();
            muzzle_position.y =
                transform.transform.translation.y + rotated_offset.y();
            muzzle_position.z =
                transform.transform.translation.z + rotated_offset.z();
            return true;
        } catch (const tf2::TransformException & ex) {
            RCLCPP_WARN_THROTTLE(
                this->get_logger(), *this->get_clock(), 2000,
                "无法查询 %s -> %s: %s",
                target_frame.c_str(), gimbal_pitch_frame_.c_str(), ex.what());
            return false;
        }
    }

    void computeAndPublish()
    {
        if (!selected_ || !target_) {
            return;
        }

        if (!selected_->valid || !target_->tracking ||
            selected_->target_id != target_->id)
        {
            publishInvalid(selected_->header, selected_->target_id, selected_->armor_index);
            return;
        }

        const std::string target_frame = selected_->header.frame_id.empty() ?
            target_->header.frame_id : selected_->header.frame_id;

        if (target_frame.empty()) {
            publishInvalid(selected_->header, selected_->target_id, selected_->armor_index);
            return;
        }

        if (!std::isfinite(bullet_speed_) || bullet_speed_ <= 0.0 ||
            !std::isfinite(gravity_) || max_iterations_ <= 0 ||
            !std::isfinite(external_delay_))
        {
            publishInvalid(selected_->header, selected_->target_id, selected_->armor_index);
            return;
        }

        geometry_msgs::msg::Point muzzle;
        if (!getMuzzlePosition(target_frame, muzzle)) {
            publishInvalid(selected_->header, selected_->target_id, selected_->armor_index);
            return;
        }

        const auto & velocity = target_->velocity;
        const auto & selected_position = selected_->pose.position;

        if (!std::isfinite(velocity.x) || !std::isfinite(velocity.y) ||
            !std::isfinite(velocity.z) || !std::isfinite(selected_position.x) ||
            !std::isfinite(selected_position.y) || !std::isfinite(selected_position.z))
        {
            publishInvalid(selected_->header, selected_->target_id, selected_->armor_index);
            return;
        }

        double horizontal = std::hypot(
            selected_position.x - muzzle.x,
            selected_position.y - muzzle.y);
        if (horizontal < 1e-4) {
            publishInvalid(selected_->header, selected_->target_id, selected_->armor_index);
            return;
        }

        // choose_Armor 已经把测量时间预测到当前时刻，这里只额外补偿外部延迟。
        double flight_time = horizontal / bullet_speed_;
        double total_lead_time = flight_time + external_delay_;
        geometry_msgs::msg::Point predicted;
        double yaw = 0.0;
        double pitch = 0.0;

        for (int i = 0; i < max_iterations_; ++i) {
            predicted.x = selected_position.x + velocity.x * total_lead_time;
            predicted.y = selected_position.y + velocity.y * total_lead_time;
            predicted.z = selected_position.z + velocity.z * total_lead_time;

            const double dx = predicted.x - muzzle.x;
            const double dy = predicted.y - muzzle.y;
            const double dz = predicted.z - muzzle.z;
            horizontal = std::hypot(dx, dy);

            if (horizontal < 1e-4) {
                publishInvalid(selected_->header, selected_->target_id, selected_->armor_index);
                return;
            }

            yaw = std::atan2(dy, dx);
            pitch = std::atan2(dz + 0.5 * gravity_ * flight_time * flight_time, horizontal);

            const double cos_pitch = std::cos(pitch);
            if (std::abs(cos_pitch) < 1e-4) {
                publishInvalid(selected_->header, selected_->target_id, selected_->armor_index);
                return;
            }

            const double next_flight_time = horizontal / (bullet_speed_ * cos_pitch);
            if (!std::isfinite(next_flight_time) || next_flight_time <= 0.0) {
                publishInvalid(selected_->header, selected_->target_id, selected_->armor_index);
                return;
            }

            if (std::abs(next_flight_time - flight_time) < 1e-5) {
                flight_time = next_flight_time;
                total_lead_time = flight_time + external_delay_;
                break;
            }
            flight_time = next_flight_time;
            total_lead_time = flight_time + external_delay_;
        }

        predicted.x = selected_position.x + velocity.x * total_lead_time;
        predicted.y = selected_position.y + velocity.y * total_lead_time;
        predicted.z = selected_position.z + velocity.z * total_lead_time;

        const double dx = predicted.x - muzzle.x;
        const double dy = predicted.y - muzzle.y;
        const double dz = predicted.z - muzzle.z;
        const double horizontal_distance = std::hypot(dx, dy);
        if (horizontal_distance < 1e-4) {
            publishInvalid(selected_->header, selected_->target_id, selected_->armor_index);
            return;
        }

        yaw = std::atan2(dy, dx);
        pitch = std::atan2(
            dz + 0.5 * gravity_ * flight_time * flight_time,
            horizontal_distance);

        auto_aim_interfaces::msg::AimCommand output;
        output.header = selected_->header;
        output.header.stamp = this->now();
        output.valid = true;
        output.target_id = selected_->target_id;
        output.armor_index = selected_->armor_index;
        output.predicted_position = predicted;
        output.yaw = yaw;
        output.pitch = pitch;
        output.distance = std::sqrt(dx * dx + dy * dy + dz * dz);
        output.flight_time = flight_time;
        output.bullet_speed = bullet_speed_;
        publisher_->publish(output);

        RCLCPP_INFO_THROTTLE(
            this->get_logger(), *this->get_clock(), 1000,
            "aim_command: target=%s armor=%d yaw=%.4f pitch=%.4f t=%.3fs",
            output.target_id.c_str(), output.armor_index,
            output.yaw, output.pitch, output.flight_time);
    }
};

}  // namespace aim_solver

int main(int argc, char ** argv)
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<aim_solver::aim_command>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
