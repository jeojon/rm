#include <rclcpp/rclcpp.hpp>

#include "auto_aim_interfaces/msg/aim_command.hpp"
#include "auto_aim_interfaces/msg/fire_command.hpp"
#include "auto_aim_interfaces/msg/globalangle.hpp"

#include <chrono>
#include <cmath>
#include <functional>
#include <memory>
#include <string>

using rclcpp::Node;

namespace aim_solver
{

class fire_control : public Node
{
    public:
    fire_control() : Node("fire_control")
    {
        yaw_tolerance_ = this->declare_parameter<double>("yaw_tolerance", 0.02);
        pitch_tolerance_ = this->declare_parameter<double>("pitch_tolerance", 0.02);
        stable_time_threshold_ = this->declare_parameter<double>("stable_time_threshold", 0.05);
        aim_timeout_ = this->declare_parameter<double>("aim_timeout", 0.10);
        gimbal_timeout_ = this->declare_parameter<double>("gimbal_timeout", 0.10);

        publisher_ = this->create_publisher<auto_aim_interfaces::msg::FireCommand>(
            "/fire_control/fire_command", 10);
        aim_subscription_ = this->create_subscription<auto_aim_interfaces::msg::AimCommand>(
            "/aim_solver/aim_command", 10,
            std::bind(&fire_control::aimCallback, this, std::placeholders::_1));
        gimbal_subscription_ =
            this->create_subscription<auto_aim_interfaces::msg::Globalangle>(
            "/gimbal/global_angle", 10,
            std::bind(&fire_control::gimbalCallback, this, std::placeholders::_1));

        timer_ = this->create_wall_timer(
            std::chrono::milliseconds(10),
            std::bind(&fire_control::publishFireCommand, this));

        RCLCPP_INFO(
            this->get_logger(),
            "fire_control started: /aim_solver/aim_command + /gimbal/global_angle -> "
            "/fire_control/fire_command");
    }

    private:
    double yaw_tolerance_;
    double pitch_tolerance_;
    double stable_time_threshold_;
    double aim_timeout_;
    double gimbal_timeout_;

    auto_aim_interfaces::msg::AimCommand::SharedPtr aim_;
    auto_aim_interfaces::msg::Globalangle::SharedPtr gimbal_;

    bool has_aim_{false};
    bool has_gimbal_{false};
    rclcpp::Time last_aim_time_;
    rclcpp::Time last_gimbal_time_;

    bool aligned_{false};
    bool has_aligned_start_{false};
    bool fire_triggered_{false};
    rclcpp::Time aligned_start_time_;
    std::string selected_target_id_;
    int selected_armor_index_{-1};

    rclcpp::Publisher<auto_aim_interfaces::msg::FireCommand>::SharedPtr publisher_;
    rclcpp::Subscription<auto_aim_interfaces::msg::AimCommand>::SharedPtr aim_subscription_;
    rclcpp::Subscription<auto_aim_interfaces::msg::Globalangle>::SharedPtr gimbal_subscription_;
    rclcpp::TimerBase::SharedPtr timer_;

    static double wrapAngle(double angle)
    {
        return std::atan2(std::sin(angle), std::cos(angle));
    }

    void aimCallback(const auto_aim_interfaces::msg::AimCommand::SharedPtr message)
    {
        aim_ = message;
        last_aim_time_ = this->now();
        has_aim_ = true;
    }

    void gimbalCallback(const auto_aim_interfaces::msg::Globalangle::SharedPtr message)
    {
        gimbal_ = message;
        last_gimbal_time_ = this->now();
        has_gimbal_ = true;
    }

    void resetAlignment()
    {
        aligned_ = false;
        has_aligned_start_ = false;
        fire_triggered_ = false;
        selected_target_id_.clear();
        selected_armor_index_ = -1;
    }

    void publishFireCommand()
    {
        auto_aim_interfaces::msg::FireCommand output;
        output.header.stamp = this->now();
        output.valid = false;

        if (!has_aim_ || !has_gimbal_ || !aim_ || !gimbal_) {
            publisher_->publish(output);
            return;
        }

        if (!aim_->header.frame_id.empty()) {
            output.header.frame_id = aim_->header.frame_id;
        }

        output.target_id = aim_->target_id;
        output.armor_index = aim_->armor_index;

        const double aim_age = (this->now() - last_aim_time_).seconds();
        const double gimbal_age = (this->now() - last_gimbal_time_).seconds();

        if (!aim_->valid || !gimbal_->valid ||
            !std::isfinite(aim_->yaw) || !std::isfinite(aim_->pitch) ||
            !std::isfinite(gimbal_->yaw) || !std::isfinite(gimbal_->pitch) ||
            aim_age > aim_timeout_ || gimbal_age > gimbal_timeout_)
        {
            resetAlignment();
            publisher_->publish(output);
            return;
        }

        output.valid = true;
        output.aim_command_age = aim_age;
        output.yaw_error = wrapAngle(aim_->yaw - gimbal_->yaw);
        output.pitch_error = aim_->pitch - gimbal_->pitch;

        if (aim_->target_id != selected_target_id_ ||
            aim_->armor_index != selected_armor_index_)
        {
            aligned_ = false;
            has_aligned_start_ = false;
            fire_triggered_ = false;
            selected_target_id_ = aim_->target_id;
            selected_armor_index_ = aim_->armor_index;
        }

        aligned_ = std::abs(output.yaw_error) <= yaw_tolerance_ &&
            std::abs(output.pitch_error) <= pitch_tolerance_;

        if (!aligned_) {
            has_aligned_start_ = false;
            fire_triggered_ = false;
            publisher_->publish(output);
            return;
        }

        if (!has_aligned_start_) {
            has_aligned_start_ = true;
            aligned_start_time_ = this->now();
        }

        output.stable_time = (this->now() - aligned_start_time_).seconds();
        output.fire_allowed = output.stable_time >= stable_time_threshold_;

        if (output.fire_allowed && !fire_triggered_) {
            output.fire_trigger = true;
            fire_triggered_ = true;
        }

        publisher_->publish(output);
    }
};

}  // namespace aim_solver

int main(int argc, char ** argv)
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<aim_solver::fire_control>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
