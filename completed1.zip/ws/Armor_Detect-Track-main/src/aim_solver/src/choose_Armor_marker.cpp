#include <rclcpp/rclcpp.hpp>

#include "auto_aim_interfaces/msg/selected_armor.hpp"
#include "auto_aim_interfaces/msg/target.hpp"

#include <tf2/LinearMath/Quaternion.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>

#include <visualization_msgs/msg/marker_array.hpp>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <functional>
#include <memory>
#include <string>
#include <vector>

using rclcpp::Node;
using namespace std::chrono_literals;

namespace aim_solver
{

class choose_Armor_marker : public Node
{
    public:
    choose_Armor_marker() : Node("choose_Armor_marker")
    {
        target_topic_ = this->declare_parameter<std::string>(
            "target_topic", "/tracker/target");
        selected_topic_ = this->declare_parameter<std::string>(
            "selected_topic", "/choose_Armor/selected_armor");
        marker_topic_ = this->declare_parameter<std::string>(
            "marker_topic", "/choose_Armor/marker");

        publisher_ = this->create_publisher<visualization_msgs::msg::MarkerArray>(
            marker_topic_, 10);
        target_subscription_ = this->create_subscription<auto_aim_interfaces::msg::Target>(
            target_topic_, rclcpp::SensorDataQoS(),
            std::bind(&choose_Armor_marker::targetCallback, this, std::placeholders::_1));
        selected_subscription_ =
            this->create_subscription<auto_aim_interfaces::msg::SelectedArmor>(
            selected_topic_, 10,
            std::bind(&choose_Armor_marker::selectedCallback, this, std::placeholders::_1));

        timer_ = this->create_wall_timer(
            100ms, std::bind(&choose_Armor_marker::publishMarkers, this));

        RCLCPP_INFO(
            this->get_logger(), "choose_Armor_marker started: %s -> %s",
            selected_topic_.c_str(), marker_topic_.c_str());
    }

    private:
    struct Candidate
    {
        int index{-1};
        double x{0.0};
        double y{0.0};
        double z{0.0};
        double yaw{0.0};
        bool valid{false};
    };

    std::string target_topic_;
    std::string selected_topic_;
    std::string marker_topic_;

    auto_aim_interfaces::msg::Target::SharedPtr target_;
    auto_aim_interfaces::msg::SelectedArmor::SharedPtr selected_;

    rclcpp::Publisher<visualization_msgs::msg::MarkerArray>::SharedPtr publisher_;
    rclcpp::Subscription<auto_aim_interfaces::msg::Target>::SharedPtr target_subscription_;
    rclcpp::Subscription<auto_aim_interfaces::msg::SelectedArmor>::SharedPtr selected_subscription_;
    rclcpp::TimerBase::SharedPtr timer_;

    void targetCallback(const auto_aim_interfaces::msg::Target::SharedPtr message)
    {
        target_ = message;
    }

    void selectedCallback(const auto_aim_interfaces::msg::SelectedArmor::SharedPtr message)
    {
        selected_ = message;
    }

    std::vector<Candidate> makeCandidates(
        const auto_aim_interfaces::msg::Target & target) const
    {
        std::vector<Candidate> candidates;
        const int armors_num = std::max(1, target.armors_num);

        for (int i = 0; i < armors_num; ++i) {
            Candidate candidate;
            candidate.index = i;

            const double phase = i * 2.0 * M_PI / static_cast<double>(armors_num);
            candidate.yaw = target.yaw + phase;

            double radius = target.radius_1;
            if (armors_num == 4) {
                radius = (i % 2 == 0) ? target.radius_1 : target.radius_2;
                candidate.z = target.position.z + ((i % 2 == 0) ? 0.0 : target.dz);
            } else {
                candidate.z = target.position.z;
            }

            if (!std::isfinite(radius) || radius <= 0.0) {
                continue;
            }

            candidate.x = target.position.x - radius * std::cos(candidate.yaw);
            candidate.y = target.position.y - radius * std::sin(candidate.yaw);
            candidate.valid = true;
            candidates.emplace_back(candidate);
        }

        return candidates;
    }

    visualization_msgs::msg::Marker makeCubeMarker(
        const std::string & frame_id,
        const std::string & name_space,
        int id,
        const Candidate & candidate,
        float r,
        float g,
        float b,
        float a) const
    {
        visualization_msgs::msg::Marker marker;
        marker.header.frame_id = frame_id;
        marker.header.stamp = this->now();
        marker.ns = name_space;
        marker.id = id;
        marker.type = visualization_msgs::msg::Marker::CUBE;
        marker.action = visualization_msgs::msg::Marker::ADD;
        marker.pose.position.x = candidate.x;
        marker.pose.position.y = candidate.y;
        marker.pose.position.z = candidate.z;

        tf2::Quaternion orientation;
        orientation.setRPY(0.0, 0.0, candidate.yaw);
        marker.pose.orientation = tf2::toMsg(orientation);

        marker.scale.x = 0.03;
        marker.scale.y = 0.18;
        marker.scale.z = 0.09;
        marker.color.r = r;
        marker.color.g = g;
        marker.color.b = b;
        marker.color.a = a;
        marker.lifetime = rclcpp::Duration::from_seconds(0.25);
        return marker;
    }

    visualization_msgs::msg::Marker makeTextMarker(
        const std::string & frame_id,
        int id,
        const Candidate & candidate,
        const std::string & text) const
    {
        visualization_msgs::msg::Marker marker;
        marker.header.frame_id = frame_id;
        marker.header.stamp = this->now();
        marker.ns = "choose_Armor_text";
        marker.id = id;
        marker.type = visualization_msgs::msg::Marker::TEXT_VIEW_FACING;
        marker.action = visualization_msgs::msg::Marker::ADD;
        marker.pose.position.x = candidate.x;
        marker.pose.position.y = candidate.y;
        marker.pose.position.z = candidate.z + 0.12;
        marker.scale.z = 0.08;
        marker.color.r = 1.0;
        marker.color.g = 1.0;
        marker.color.b = 1.0;
        marker.color.a = 1.0;
        marker.text = text;
        marker.lifetime = rclcpp::Duration::from_seconds(0.25);
        return marker;
    }

    void publishMarkers()
    {
        visualization_msgs::msg::MarkerArray array;

        if (!target_ || !target_->tracking || !selected_ || !selected_->valid) {
            visualization_msgs::msg::Marker clear;
            clear.header.frame_id = target_ && !target_->header.frame_id.empty() ?
                target_->header.frame_id : "odom";
            clear.header.stamp = this->now();
            clear.ns = "choose_Armor";
            clear.id = 0;
            clear.action = visualization_msgs::msg::Marker::DELETEALL;
            array.markers.emplace_back(clear);
            publisher_->publish(array);
            return;
        }

        const std::string frame_id = target_->header.frame_id.empty() ?
            "odom" : target_->header.frame_id;
        const auto candidates = makeCandidates(*target_);

        // 目标中心
        visualization_msgs::msg::Marker center;
        center.header.frame_id = frame_id;
        center.header.stamp = this->now();
        center.ns = "choose_Armor_center";
        center.id = 0;
        center.type = visualization_msgs::msg::Marker::SPHERE;
        center.action = visualization_msgs::msg::Marker::ADD;
        center.pose.position = target_->position;
        center.scale.x = 0.05;
        center.scale.y = 0.05;
        center.scale.z = 0.05;
        center.color.r = 0.2F;
        center.color.g = 1.0F;
        center.color.b = 0.2F;
        center.color.a = 0.8F;
        center.lifetime = rclcpp::Duration::from_seconds(0.25);
        array.markers.emplace_back(center);

        for (const auto & candidate : candidates) {
            if (!candidate.valid) {
                continue;
            }

            const bool is_selected = candidate.index == selected_->armor_index;
            if (is_selected) {
                array.markers.emplace_back(
                    makeCubeMarker(frame_id, "choose_Armor_selected", 100 + candidate.index,
                                   candidate, 1.0F, 0.0F, 0.0F, 1.0F));
            } else {
                array.markers.emplace_back(
                    makeCubeMarker(frame_id, "choose_Armor_candidates", candidate.index,
                                   candidate, 0.5F, 0.5F, 0.5F, 0.6F));
            }

            array.markers.emplace_back(
                makeTextMarker(frame_id, 200 + candidate.index, candidate,
                               std::to_string(candidate.index)));
        }

        publisher_->publish(array);
    }
};

}  // namespace aim_solver

int main(int argc, char ** argv)
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<aim_solver::choose_Armor_marker>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
