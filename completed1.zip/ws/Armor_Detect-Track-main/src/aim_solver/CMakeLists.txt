cmake_minimum_required(VERSION 3.8)
project(aim_solver)

if(CMAKE_COMPILER_IS_GNUCXX OR CMAKE_CXX_COMPILER_ID MATCHES "Clang")
  add_compile_options(-Wall -Wextra -Wpedantic)
endif()

find_package(ament_cmake REQUIRED)
find_package(rclcpp REQUIRED)
find_package(auto_aim_interfaces REQUIRED)
find_package(std_msgs REQUIRED)
find_package(geometry_msgs REQUIRED)
find_package(tf2 REQUIRED)
find_package(tf2_ros REQUIRED)
find_package(tf2_geometry_msgs REQUIRED)
find_package(visualization_msgs REQUIRED)

add_executable(choose_Armor src/choose_Armor.cpp)
target_compile_features(choose_Armor PRIVATE cxx_std_17)
ament_target_dependencies(
  choose_Armor
  rclcpp
  auto_aim_interfaces
  std_msgs
  geometry_msgs
  tf2
  tf2_ros
  tf2_geometry_msgs
)

add_executable(choose_Armor_marker src/choose_Armor_marker.cpp)
target_compile_features(choose_Armor_marker PRIVATE cxx_std_17)
ament_target_dependencies(
  choose_Armor_marker
  rclcpp
  auto_aim_interfaces
  std_msgs
  geometry_msgs
  tf2
  tf2_geometry_msgs
  visualization_msgs
)

add_executable(aim_command src/aim_command.cpp)
target_include_directories(aim_command PRIVATE
  ${CMAKE_CURRENT_SOURCE_DIR}/include
)
target_compile_features(aim_command PRIVATE cxx_std_17)
ament_target_dependencies(
  aim_command
  rclcpp
  auto_aim_interfaces
  std_msgs
  geometry_msgs
  tf2
  tf2_ros
  tf2_geometry_msgs
)

add_executable(fire_control src/fire_control.cpp)
target_compile_features(fire_control PRIVATE cxx_std_17)
ament_target_dependencies(
  fire_control
  rclcpp
  auto_aim_interfaces
  std_msgs
)

install(TARGETS
  choose_Armor
  choose_Armor_marker
  aim_command
  fire_control
  DESTINATION lib/${PROJECT_NAME}
)

if(BUILD_TESTING)
  find_package(ament_lint_auto REQUIRED)
  set(ament_cmake_copyright_FOUND TRUE)
  set(ament_cmake_cpplint_FOUND TRUE)
  ament_lint_auto_find_test_dependencies()
endif()

ament_package()
