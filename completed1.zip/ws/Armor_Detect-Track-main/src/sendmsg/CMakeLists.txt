cmake_minimum_required(VERSION 3.8)
project(sendmsg)

if(CMAKE_COMPILER_IS_GNUCXX OR CMAKE_CXX_COMPILER_ID MATCHES "Clang")
  add_compile_options(-Wall -Wextra -Wpedantic)
endif()

find_package(ament_cmake REQUIRED)
find_package(rclcpp REQUIRED)
find_package(sensor_msgs REQUIRED)
find_package(auto_aim_interfaces REQUIRED)

add_executable(sendmsg src/sendmsg.cpp)
target_compile_features(sendmsg PRIVATE cxx_std_17)
ament_target_dependencies(
  sendmsg
  rclcpp
  auto_aim_interfaces
)

add_executable(imu_euler_solver src/imu_euler_solver.cpp)
target_compile_features(imu_euler_solver PRIVATE cxx_std_17)
ament_target_dependencies(
  imu_euler_solver
  rclcpp
  sensor_msgs
  auto_aim_interfaces
)

install(TARGETS
  sendmsg
  imu_euler_solver
  DESTINATION lib/${PROJECT_NAME}
)

if(BUILD_TESTING)
  find_package(ament_lint_auto REQUIRED)
  set(ament_cmake_copyright_FOUND TRUE)
  set(ament_cmake_cpplint_FOUND TRUE)
  ament_lint_auto_find_test_dependencies()
endif()

ament_package()
