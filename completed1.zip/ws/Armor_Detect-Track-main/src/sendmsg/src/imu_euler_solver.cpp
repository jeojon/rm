#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/imu.hpp>

#include "auto_aim_interfaces/msg/imu_euler_data.hpp"

#include <algorithm>
#include <cmath>
#include <functional>
#include <memory>
#include <string>

namespace sendmsg
{

class ImuEulerSolver : public rclcpp::Node
{
public:
  ImuEulerSolver()
  : Node("imu_euler_solver")
  {
    input_topic_ = declare_parameter<std::string>("input_topic", "/imu");
    output_topic_ = declare_parameter<std::string>("output_topic", "/imu_euler_data");

    publisher_ =
      create_publisher<auto_aim_interfaces::msg::ImuEulerData>(output_topic_, 10);
    subscription_ = create_subscription<sensor_msgs::msg::Imu>(
      input_topic_, 10,
      std::bind(&ImuEulerSolver::imuCallback, this, std::placeholders::_1));

    RCLCPP_INFO(
      get_logger(), "imu_euler_solver started: %s -> %s",
      input_topic_.c_str(), output_topic_.c_str());
  }

private:
  void imuCallback(const sensor_msgs::msg::Imu::SharedPtr message)
  {
    const auto & q = message->orientation;
    if (!std::isfinite(q.x) || !std::isfinite(q.y) ||
      !std::isfinite(q.z) || !std::isfinite(q.w))
    {
      RCLCPP_WARN_THROTTLE(
        get_logger(), *get_clock(), 5000, "Ignoring IMU message with invalid quaternion");
      return;
    }

    if (message->orientation_covariance[0] < 0.0) {
      RCLCPP_WARN_THROTTLE(
        get_logger(), *get_clock(), 5000,
        "Ignoring IMU message without a valid orientation estimate");
      return;
    }

    const double norm = std::sqrt(q.x * q.x + q.y * q.y + q.z * q.z + q.w * q.w);
    if (!std::isfinite(norm) || norm < 1e-6) {
      RCLCPP_WARN_THROTTLE(
        get_logger(), *get_clock(), 5000, "Ignoring IMU message with zero quaternion");
      return;
    }

    const double x = q.x / norm;
    const double y = q.y / norm;
    const double z = q.z / norm;
    const double w = q.w / norm;

    const double roll = std::atan2(
      2.0 * (w * x + y * z),
      1.0 - 2.0 * (x * x + y * y));
    const double pitch = std::asin(std::clamp(
      2.0 * (w * y - z * x), -1.0, 1.0));
    const double yaw = std::atan2(
      2.0 * (w * z + x * y),
      1.0 - 2.0 * (y * y + z * z));

    const auto & angular_velocity = message->angular_velocity;
    const auto & linear_acceleration = message->linear_acceleration;
    if (!std::isfinite(roll) || !std::isfinite(pitch) || !std::isfinite(yaw) ||
      !std::isfinite(angular_velocity.x) || !std::isfinite(angular_velocity.y) ||
      !std::isfinite(angular_velocity.z) ||
      !std::isfinite(linear_acceleration.x) ||
      !std::isfinite(linear_acceleration.y) ||
      !std::isfinite(linear_acceleration.z))
    {
      RCLCPP_WARN_THROTTLE(
        get_logger(), *get_clock(), 5000, "Ignoring IMU message with non-finite data");
      return;
    }

    auto_aim_interfaces::msg::ImuEulerData output;
    output.header = message->header;
    output.roll = static_cast<float>(roll);
    output.pitch = static_cast<float>(pitch);
    output.yaw = static_cast<float>(yaw);
    output.angular_velocity_x = static_cast<float>(angular_velocity.x);
    output.angular_velocity_y = static_cast<float>(angular_velocity.y);
    output.angular_velocity_z = static_cast<float>(angular_velocity.z);
    output.linear_acceleration_x = static_cast<float>(linear_acceleration.x);
    output.linear_acceleration_y = static_cast<float>(linear_acceleration.y);
    output.linear_acceleration_z = static_cast<float>(linear_acceleration.z);

    publisher_->publish(output);
  }

  std::string input_topic_;
  std::string output_topic_;
  rclcpp::Publisher<auto_aim_interfaces::msg::ImuEulerData>::SharedPtr publisher_;
  rclcpp::Subscription<sensor_msgs::msg::Imu>::SharedPtr subscription_;
};

}  // namespace sendmsg

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  auto node = std::make_shared<sendmsg::ImuEulerSolver>();
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}
