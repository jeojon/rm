#include <rclcpp/rclcpp.hpp>

#include "auto_aim_interfaces/msg/aim_command.hpp"
#include "auto_aim_interfaces/msg/datainterface.hpp"
#include "auto_aim_interfaces/msg/fire_command.hpp"

#include <chrono>
#include <cmath>
#include <functional>
#include <memory>

namespace sendmsg
{

class SendMsg : public rclcpp::Node
{
public:
  SendMsg()
  : Node("sendmsg")
  {
    publish_rate_hz_ = declare_parameter<double>("publish_rate_hz", 20.0);
    target_timeout_s_ = declare_parameter<double>("target_timeout_s", 0.0);
    fire_timeout_s_ = declare_parameter<double>("fire_timeout_s", 0.10);
    if (publish_rate_hz_ <= 0.0) {
      publish_rate_hz_ = 20.0;
    }

    publisher_ =
      create_publisher<auto_aim_interfaces::msg::Datainterface>("/ultimate", 10);
    aim_subscription_ =
      create_subscription<auto_aim_interfaces::msg::AimCommand>(
      "/aim_solver/aim_command", 10,
      std::bind(&SendMsg::aimCommandCallback, this, std::placeholders::_1));
    fire_subscription_ =
      create_subscription<auto_aim_interfaces::msg::FireCommand>(
      "/fire_control/fire_command", 10,
      std::bind(&SendMsg::fireCommandCallback, this, std::placeholders::_1));

    timer_ = create_wall_timer(
      std::chrono::duration<double>(1.0 / publish_rate_hz_),
      std::bind(&SendMsg::publishLatest, this));

    RCLCPP_INFO(
      get_logger(),
      "sendmsg started: /aim_solver/aim_command + /fire_control/fire_command -> "
      "/ultimate at %.1f Hz",
      publish_rate_hz_);
  }

private:
  void aimCommandCallback(const auto_aim_interfaces::msg::AimCommand::SharedPtr message)
  {
    if (!message->valid || !std::isfinite(message->yaw) || !std::isfinite(message->pitch)) {
      return;
    }

    yaw_ = message->yaw;
    pitch_ = message->pitch;
    last_aim_update_ = now();
    has_aim_ = true;
  }

  void fireCommandCallback(const auto_aim_interfaces::msg::FireCommand::SharedPtr message)
  {
    if (!message) {
      return;
    }

    last_fire_update_ = now();
    has_fire_ = true;
    fire_allowed_ = message->valid && message->fire_allowed;

    if (message->valid && message->fire_trigger) {
      fire_trigger_latched_ = true;
    }
  }

  void publishLatest()
  {
    auto_aim_interfaces::msg::Datainterface output;

    const bool aim_valid = has_aim_ && (
      target_timeout_s_ <= 0.0 || (now() - last_aim_update_).seconds() <= target_timeout_s_);
    const bool fire_valid = has_fire_ &&
      (now() - last_fire_update_).seconds() <= fire_timeout_s_;

    output.yaw = aim_valid ? static_cast<float>(yaw_) : 0.0F;
    output.pitch = aim_valid ? static_cast<float>(pitch_) : 0.0F;
    output.w = 0.0F;

    output.fire_allowed = aim_valid && fire_valid && fire_allowed_;
    output.fire_trigger = output.fire_allowed && fire_trigger_latched_;

    // 单次触发只下发一个发布周期
    fire_trigger_latched_ = false;

    publisher_->publish(output);
  }

  double publish_rate_hz_;
  double target_timeout_s_;
  double fire_timeout_s_;
  bool has_aim_{false};
  bool has_fire_{false};
  bool fire_allowed_{false};
  bool fire_trigger_latched_{false};
  double yaw_{0.0};
  double pitch_{0.0};
  rclcpp::Time last_aim_update_;
  rclcpp::Time last_fire_update_;
  rclcpp::Publisher<auto_aim_interfaces::msg::Datainterface>::SharedPtr publisher_;
  rclcpp::Subscription<auto_aim_interfaces::msg::AimCommand>::SharedPtr aim_subscription_;
  rclcpp::Subscription<auto_aim_interfaces::msg::FireCommand>::SharedPtr fire_subscription_;
  rclcpp::TimerBase::SharedPtr timer_;
};

}  // namespace sendmsg

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  auto node = std::make_shared<sendmsg::SendMsg>();
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}
