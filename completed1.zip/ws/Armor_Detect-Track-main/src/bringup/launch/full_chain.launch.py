from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.conditions import IfCondition, UnlessCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    use_hik_camera = LaunchConfiguration("use_hik_camera")
    use_yolo = LaunchConfiguration("use_yolo")
    debug = LaunchConfiguration("debug")
    start_serial = LaunchConfiguration("start_serial")
    binary_thres = LaunchConfiguration("binary_thres")
    classifier_threshold = LaunchConfiguration("classifier_threshold")
    target_frame = LaunchConfiguration("target_frame")
    bullet_speed = LaunchConfiguration("bullet_speed")
    serial_delay = LaunchConfiguration("serial_delay")
    gimbal_delay = LaunchConfiguration("gimbal_delay")
    fire_delay = LaunchConfiguration("fire_delay")
    send_rate = LaunchConfiguration("send_rate")

    detector_parameters = {
        "debug": ParameterValue(debug, value_type=bool),
        "binary_thres": ParameterValue(binary_thres, value_type=int),
        "classifier_threshold": ParameterValue(
            classifier_threshold, value_type=float
        ),
    }

    return LaunchDescription(
        [
            DeclareLaunchArgument(
                "use_hik_camera",
                default_value="true",
                description="Start hik_camera; false when using an external image source",
            ),
            DeclareLaunchArgument(
                "use_yolo",
                default_value="true",
                description="Run yolo_node before armor_detector",
            ),
            DeclareLaunchArgument(
                "debug",
                default_value="false",
                description="Enable detector debug topics and choose_Armor marker",
            ),
            DeclareLaunchArgument(
                "start_serial",
                default_value="false",
                description="Start senddata serial bridge",
            ),
            DeclareLaunchArgument(
                "binary_thres",
                default_value="160",
                description="Traditional armor detector gray threshold",
            ),
            DeclareLaunchArgument(
                "classifier_threshold",
                default_value="0.7",
                description="Number classifier confidence threshold",
            ),
            DeclareLaunchArgument(
                "target_frame",
                default_value="odom",
                description="Tracker target frame",
            ),
            DeclareLaunchArgument(
                "bullet_speed",
                default_value="14.0",
                description="Bullet speed in m/s",
            ),
            DeclareLaunchArgument(
                "serial_delay",
                default_value="0.0",
                description="Serial/bus delay in seconds",
            ),
            DeclareLaunchArgument(
                "gimbal_delay",
                default_value="0.0",
                description="Gimbal response delay in seconds",
            ),
            DeclareLaunchArgument(
                "fire_delay",
                default_value="0.0",
                description="Firing mechanism delay in seconds",
            ),
            DeclareLaunchArgument(
                "send_rate",
                default_value="20.0",
                description="Ultimate output rate in Hz",
            ),
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource(
                    PathJoinSubstitution(
                        [
                            FindPackageShare("hik_camera"),
                            "launch",
                            "hik_camera.launch.py",
                        ]
                    )
                ),
                condition=IfCondition(use_hik_camera),
            ),
            Node(
                package="yolo_node",
                executable="yolo_roi_node",
                name="yolo_roi_node",
                output="screen",
                condition=IfCondition(use_yolo),
            ),
            Node(
                package="armor_detector",
                executable="armor_detector_node",
                name="armor_detector",
                output="screen",
                condition=IfCondition(use_yolo),
                parameters=[{**detector_parameters, "image_topic": "/detector/image_roi"}],
            ),
            Node(
                package="armor_detector",
                executable="armor_detector_node",
                name="armor_detector",
                output="screen",
                condition=UnlessCondition(use_yolo),
                parameters=[{**detector_parameters, "image_topic": "/image_raw"}],
            ),
            Node(
                package="transform",
                executable="get_globalAngle",
                name="get_global_angle",
                output="screen",
            ),
            Node(
                package="transform",
                executable="publish_tf",
                name="publish_tf",
                output="screen",
            ),
            Node(
                package="armor_tracker",
                executable="armor_tracker_node",
                name="armor_tracker",
                output="screen",
                parameters=[{"target_frame": target_frame}],
            ),
            Node(
                package="aim_solver",
                executable="choose_Armor",
                name="choose_Armor",
                output="screen",
            ),
            Node(
                package="aim_solver",
                executable="choose_Armor_marker",
                name="choose_Armor_marker",
                output="screen",
                condition=IfCondition(debug),
            ),
            Node(
                package="aim_solver",
                executable="aim_command",
                name="aim_command",
                output="screen",
                parameters=[
                    {
                        "bullet_speed": ParameterValue(bullet_speed, value_type=float),
                        "serial_delay": ParameterValue(serial_delay, value_type=float),
                        "gimbal_delay": ParameterValue(gimbal_delay, value_type=float),
                        "fire_delay": ParameterValue(fire_delay, value_type=float),
                    }
                ],
            ),
            Node(
                package="aim_solver",
                executable="fire_control",
                name="fire_control",
                output="screen",
            ),
            Node(
                package="sendmsg",
                executable="sendmsg",
                name="sendmsg",
                output="screen",
                parameters=[{"publish_rate_hz": ParameterValue(send_rate, value_type=float)}],
            ),
            Node(
                package="senddata",
                executable="senddata",
                name="senddata",
                output="screen",
                condition=IfCondition(start_serial),
            ),
        ]
    )
