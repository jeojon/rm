from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    use_hik_camera = LaunchConfiguration("use_hik_camera")
    use_classifier = LaunchConfiguration("use_classifier")
    debug = LaunchConfiguration("debug")
    start_serial = LaunchConfiguration("start_serial")
    binary_thres = LaunchConfiguration("binary_thres")
    classifier_threshold = LaunchConfiguration("classifier_threshold")
    target_frame = LaunchConfiguration("target_frame")
    bullet_speed = LaunchConfiguration("bullet_speed")
    serial_delay = LaunchConfiguration("serial_delay")
    gimbal_delay = LaunchConfiguration("gimbal_delay")
    fire_delay = LaunchConfiguration("fire_delay")
    send_rate = LaunchConfiguration("send_rate")

    return LaunchDescription(
        [
            DeclareLaunchArgument(
                "use_hik_camera",
                default_value="true",
                description="Start hik_camera; false when using an external image source",
            ),
            DeclareLaunchArgument(
                "use_classifier",
                default_value="false",
                description="Enable armor number classifier",
            ),
            DeclareLaunchArgument(
                "debug",
                default_value="false",
                description="Enable detector debug topics and choose_Armor marker",
            ),
            DeclareLaunchArgument(
                "start_serial",
                default_value="false",
                description="Start senddata serial bridge",
            ),
            DeclareLaunchArgument(
                "binary_thres",
                default_value="80",
                description="Traditional armor detector gray threshold",
            ),
            DeclareLaunchArgument(
                "classifier_threshold",
                default_value="0.7",
                description="Number classifier confidence threshold",
            ),
            DeclareLaunchArgument(
                "target_frame",
                default_value="odom",
                description="Tracker target frame",
            ),
            DeclareLaunchArgument(
                "bullet_speed",
                default_value="14.0",
                description="Bullet speed in m/s",
            ),
            DeclareLaunchArgument(
                "serial_delay",
                default_value="0.0",
                description="Serial/bus delay in seconds",
            ),
            DeclareLaunchArgument(
                "gimbal_delay",
                default_value="0.0",
                description="Gimbal response delay in seconds",
            ),
            DeclareLaunchArgument(
                "fire_delay",
                default_value="0.0",
                description="Firing mechanism delay in seconds",
            ),
            DeclareLaunchArgument(
                "send_rate",
                default_value="20.0",
                description="Ultimate output rate in Hz",
            ),
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource(
                    PathJoinSubstitution(
                        [
                            FindPackageShare("hik_camera"),
                            "launch",
                            "hik_camera.launch.py",
                        ]
                    )
                ),
                condition=IfCondition(use_hik_camera),
            ),
            Node(
                package="armor_detector",
                executable="armor_detector_node",
                name="armor_detector",
                output="screen",
                parameters=[
                    {
                        "image_topic": "/image_raw",
                        "use_classifier": ParameterValue(use_classifier, value_type=bool),
                        "debug": ParameterValue(debug, value_type=bool),
                        "binary_thres": ParameterValue(binary_thres, value_type=int),
                        "classifier_threshold": ParameterValue(
                            classifier_threshold, value_type=float
                        ),
                    }
                ],
            ),
            Node(
                package="transform",
                executable="get_globalAngle",
                name="get_global_angle",
                output="screen",
            ),
            Node(
                package="transform",
                executable="publish_tf",
                name="publish_tf",
                output="screen",
            ),
            Node(
                package="transform",
                executable="imu_angle_bridge",
                name="imu_angle_bridge",
                output="screen",
            ),
            Node(
                package="armor_tracker",
                executable="armor_tracker_node",
                name="armor_tracker",
                output="screen",
                parameters=[{"target_frame": target_frame}],
            ),
            Node(
                package="aim_solver",
                executable="choose_Armor",
                name="choose_Armor",
                output="screen",
            ),
            Node(
                package="aim_solver",
                executable="choose_Armor_marker",
                name="choose_Armor_marker",
                output="screen",
                condition=IfCondition(debug),
            ),
            Node(
                package="aim_solver",
                executable="aim_command",
                name="aim_command",
                output="screen",
                parameters=[
                    {
                        "bullet_speed": ParameterValue(bullet_speed, value_type=float),
                        "serial_delay": ParameterValue(serial_delay, value_type=float),
                        "gimbal_delay": ParameterValue(gimbal_delay, value_type=float),
                        "fire_delay": ParameterValue(fire_delay, value_type=float),
                    }
                ],
            ),
            Node(
                package="aim_solver",
                executable="fire_control",
                name="fire_control",
                output="screen",
            ),
            Node(
                package="sendmsg",
                executable="sendmsg",
                name="sendmsg",
                output="screen",
                parameters=[{"publish_rate_hz": ParameterValue(send_rate, value_type=float)}],
            ),
            Node(
                package="sendmsg",
                executable="imu_euler_solver",
                name="imu_euler_solver",
                output="screen",
            ),
            Node(
                package="senddata",
                executable="senddata",
                name="senddata",
                output="screen",
                condition=IfCondition(start_serial),
            ),
        ]
    )
