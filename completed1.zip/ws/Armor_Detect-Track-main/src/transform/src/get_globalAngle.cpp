#include <rclcpp/rclcpp.hpp>

#include "auto_aim_interfaces/msg/globalangle.hpp"

#include <cmath>
#include <functional>
#include <memory>

using rclcpp::Node;

// 这个节点负责接受接受发布的云台坐标用于后续tf变换和开火指令的判断
// 1. 接收下位机通信节点发布的原始云台角度
// 2. 检查数据是否有效
// 3. 更新时间戳和坐标系名称
// 4. 发布给后面的 publish_tf 节点

class global_angle_node : public Node
{
    public:
    global_angle_node() : Node("get_global_angle")
    {
        RCLCPP_INFO(this->get_logger(), "云台角度转发节点已经创建!!!");

        // 发布给 publish_tf 节点
        publisher_ = this->create_publisher<auto_aim_interfaces::msg::Globalangle>(
            "/gimbal/global_angle", 10);

        // 接收下位机通信节点发布的角度
        subscription_ = this->create_subscription<auto_aim_interfaces::msg::Globalangle>(
            "/gimbal/raw_angle", 10,
            std::bind(&global_angle_node::deal, this, std::placeholders::_1));
    }

    private:
    rclcpp::Publisher<auto_aim_interfaces::msg::Globalangle>::SharedPtr publisher_;
    rclcpp::Subscription<auto_aim_interfaces::msg::Globalangle>::SharedPtr subscription_;

    void deal(const auto_aim_interfaces::msg::Globalangle::SharedPtr msg)
    {
        // valid=false 表示下位机当前没有有效云台角度
        if (!msg->valid) {
            RCLCPP_WARN_THROTTLE(
                this->get_logger(), *this->get_clock(), 2000,
                "收到的云台角度无效，不发布");
            return;
        }

        // yaw 或 pitch 不是正常数字时也不能使用
        if (!std::isfinite(msg->yaw) || !std::isfinite(msg->pitch)) {
            RCLCPP_WARN_THROTTLE(
                this->get_logger(), *this->get_clock(), 2000,
                "收到的云台角度不是正常数值，不发布");
            return;
        }

        auto message = auto_aim_interfaces::msg::Globalangle();

        // 使用当前 ROS 时间，保证 TF 节点拿到的是新的时间戳
        message.header.stamp = this->now();
        message.header.frame_id = "gimbal_feedback";
        message.yaw = msg->yaw;
        message.pitch = msg->pitch;
        message.valid = true;

        RCLCPP_INFO_THROTTLE(
            this->get_logger(), *this->get_clock(), 1000,
            "发布云台角度: yaw = %.6f, pitch = %.6f",
            message.yaw, message.pitch);

        publisher_->publish(message);
    }
};

int main(int argc, char** argv)
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<global_angle_node>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
