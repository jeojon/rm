#include <rclcpp/rclcpp.hpp>

#include "auto_aim_interfaces/msg/globalangle.hpp"
#include <geometry_msgs/msg/vector3.hpp>

#include <cmath>
#include <functional>
#include <memory>
#include <string>

using rclcpp::Node;

class imu_angle_bridge : public Node
{
    public:
    imu_angle_bridge() : Node("imu_angle_bridge")
    {
        input_topic_ = this->declare_parameter<std::string>(
            "input_topic", "/euler_angles");
        output_topic_ = this->declare_parameter<std::string>(
            "output_topic", "/gimbal/raw_angle");
        output_frame_id_ = this->declare_parameter<std::string>(
            "output_frame_id", "gimbal_feedback");

        publisher_ = this->create_publisher<auto_aim_interfaces::msg::Globalangle>(
            output_topic_, 10);
        subscription_ = this->create_subscription<geometry_msgs::msg::Vector3>(
            input_topic_, 10,
            std::bind(&imu_angle_bridge::eulerCallback, this, std::placeholders::_1));

        RCLCPP_INFO(
            this->get_logger(), "imu_angle_bridge started: %s -> %s",
            input_topic_.c_str(), output_topic_.c_str());
    }

    private:
    std::string input_topic_;
    std::string output_topic_;
    std::string output_frame_id_;

    rclcpp::Publisher<auto_aim_interfaces::msg::Globalangle>::SharedPtr publisher_;
    rclcpp::Subscription<geometry_msgs::msg::Vector3>::SharedPtr subscription_;

    void eulerCallback(const geometry_msgs::msg::Vector3::SharedPtr message)
    {
        // euler_angles: x=roll, y=pitch, z=yaw
        if (!std::isfinite(message->y) || !std::isfinite(message->z)) {
            return;
        }

        auto_aim_interfaces::msg::Globalangle output;
        output.header.stamp = this->now();
        output.header.frame_id = output_frame_id_;
        output.yaw = message->z;
        output.pitch = message->y;
        output.valid = true;
        publisher_->publish(output);
    }
};

int main(int argc, char ** argv)
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<imu_angle_bridge>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
