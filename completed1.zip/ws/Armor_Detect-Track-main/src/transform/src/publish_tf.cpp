#include <rclcpp/rclcpp.hpp>

#include "auto_aim_interfaces/msg/globalangle.hpp"

#include <geometry_msgs/msg/transform_stamped.hpp>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>
#include <tf2_ros/static_transform_broadcaster.h>
#include <tf2_ros/transform_broadcaster.h>

#include <cmath>
#include <functional>
#include <memory>
#include <string>
#include <vector>

using rclcpp::Node;

class publish_tf : public Node
{
    public:
    publish_tf() : Node("publish_tf")
    {
        RCLCPP_INFO(this->get_logger(), "云台 TF 发布节点已经创建!!!");

        input_topic_ = this->declare_parameter<std::string>(
            "input_topic", "/gimbal/global_angle");
        odom_frame_ = this->declare_parameter<std::string>(
            "odom_frame", "odom");
        yaw_frame_ = this->declare_parameter<std::string>(
            "yaw_frame", "gimbal_yaw");
        pitch_frame_ = this->declare_parameter<std::string>(
            "pitch_frame", "gimbal_pitch");
        camera_frame_ = this->declare_parameter<std::string>(
            "camera_frame", "camera_optical_frame");

        // 相机相对云台的安装位置，单位：米
        camera_x_ = this->declare_parameter<double>("camera_x", 0.07123);
        camera_y_ = this->declare_parameter<double>("camera_y", 0.0);
        camera_z_ = this->declare_parameter<double>("camera_z", 0.18188);

        // 如果实际电机方向与定义相反，把对应参数设为 -1.0
        yaw_sign_ = this->declare_parameter<double>("yaw_sign", 1.0);
        pitch_sign_ = this->declare_parameter<double>("pitch_sign", 1.0);

        tf_broadcaster_ = std::make_unique<tf2_ros::TransformBroadcaster>(*this);
        static_tf_broadcaster_ =
            std::make_unique<tf2_ros::StaticTransformBroadcaster>(*this);

        publishStaticCameraTransform();

        subscription_ = this->create_subscription<auto_aim_interfaces::msg::Globalangle>(
            input_topic_, 10,
            std::bind(&publish_tf::deal, this, std::placeholders::_1));
    }

    private:
    std::string input_topic_;
    std::string odom_frame_;
    std::string yaw_frame_;
    std::string pitch_frame_;
    std::string camera_frame_;
    double camera_x_;
    double camera_y_;
    double camera_z_;
    double yaw_sign_;
    double pitch_sign_;

    std::unique_ptr<tf2_ros::TransformBroadcaster> tf_broadcaster_;
    std::unique_ptr<tf2_ros::StaticTransformBroadcaster> static_tf_broadcaster_;
    rclcpp::Subscription<auto_aim_interfaces::msg::Globalangle>::SharedPtr subscription_;

    void publishStaticCameraTransform()
    {
        geometry_msgs::msg::TransformStamped camera_tf;

        camera_tf.header.stamp = this->now();
        camera_tf.header.frame_id = pitch_frame_;
        camera_tf.child_frame_id = camera_frame_;

        // 相机光心相对云台 pitch 轴的安装位置
        camera_tf.transform.translation.x = camera_x_;
        camera_tf.transform.translation.y = camera_y_;
        camera_tf.transform.translation.z = camera_z_;

        // 从云台坐标系(x前,y左,z上)转换到相机光学坐标系(x右,y下,z前)
        tf2::Quaternion camera_rotation;
        camera_rotation.setRPY(-M_PI_2, 0.0, -M_PI_2);
        camera_tf.transform.rotation = tf2::toMsg(camera_rotation);

        static_tf_broadcaster_->sendTransform(camera_tf);

        RCLCPP_INFO(
            this->get_logger(),
            "发布静态 TF: %s -> %s, xyz=(%.5f, %.5f, %.5f)",
            pitch_frame_.c_str(), camera_frame_.c_str(),
            camera_x_, camera_y_, camera_z_);
    }

    void deal(const auto_aim_interfaces::msg::Globalangle::SharedPtr msg)
    {
        if (!msg->valid) {
            return;
        }

        if (!std::isfinite(msg->yaw) || !std::isfinite(msg->pitch)) {
            return;
        }

        const double yaw = yaw_sign_ * msg->yaw;
        const double pitch = pitch_sign_ * msg->pitch;

        // odom -> gimbal_yaw
        geometry_msgs::msg::TransformStamped yaw_tf;
        yaw_tf.header.stamp = msg->header.stamp;
        yaw_tf.header.frame_id = odom_frame_;
        yaw_tf.child_frame_id = yaw_frame_;
        yaw_tf.transform.translation.x = 0.0;
        yaw_tf.transform.translation.y = 0.0;
        yaw_tf.transform.translation.z = 0.0;

        tf2::Quaternion yaw_rotation;
        yaw_rotation.setRPY(0.0, 0.0, yaw);
        yaw_tf.transform.rotation = tf2::toMsg(yaw_rotation);

        // gimbal_yaw -> gimbal_pitch
        geometry_msgs::msg::TransformStamped pitch_tf;
        pitch_tf.header.stamp = msg->header.stamp;
        pitch_tf.header.frame_id = yaw_frame_;
        pitch_tf.child_frame_id = pitch_frame_;
        pitch_tf.transform.translation.x = 0.0;
        pitch_tf.transform.translation.y = 0.0;
        pitch_tf.transform.translation.z = 0.0;

        tf2::Quaternion pitch_rotation;
        pitch_rotation.setRPY(0.0, pitch, 0.0);
        pitch_tf.transform.rotation = tf2::toMsg(pitch_rotation);

        tf_broadcaster_->sendTransform(yaw_tf);
        tf_broadcaster_->sendTransform(pitch_tf);

        RCLCPP_INFO_THROTTLE(
            this->get_logger(), *this->get_clock(), 1000,
            "发布动态 TF: yaw = %.6f rad, pitch = %.6f rad",
            yaw, pitch);
    }
};

int main(int argc, char** argv)
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<publish_tf>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
