cmake_minimum_required(VERSION 3.8)
project(transform)

if(CMAKE_COMPILER_IS_GNUCXX OR CMAKE_CXX_COMPILER_ID MATCHES "Clang")
  add_compile_options(-Wall -Wextra -Wpedantic)
endif()

find_package(ament_cmake REQUIRED)
find_package(rclcpp REQUIRED)
find_package(auto_aim_interfaces REQUIRED)
find_package(std_msgs REQUIRED)
find_package(geometry_msgs REQUIRED)
find_package(tf2 REQUIRED)
find_package(tf2_ros REQUIRED)
find_package(tf2_geometry_msgs REQUIRED)

# 接收下位机通信节点发布的原始云台角度，处理后转发给 TF 节点
add_executable(get_globalAngle src/get_globalAngle.cpp)
target_compile_features(get_globalAngle PRIVATE cxx_std_17)
ament_target_dependencies(
  get_globalAngle
  rclcpp
  auto_aim_interfaces
  std_msgs
)

# 根据云台角度发布动态 TF，并发布相机安装外参静态 TF
add_executable(publish_tf src/publish_tf.cpp)
target_compile_features(publish_tf PRIVATE cxx_std_17)
ament_target_dependencies(
  publish_tf
  rclcpp
  auto_aim_interfaces
  std_msgs
  geometry_msgs
  tf2
  tf2_ros
  tf2_geometry_msgs
)

add_executable(imu_angle_bridge src/imu_angle_bridge.cpp)
target_compile_features(imu_angle_bridge PRIVATE cxx_std_17)
ament_target_dependencies(
  imu_angle_bridge
  rclcpp
  auto_aim_interfaces
  std_msgs
  geometry_msgs
)

install(TARGETS
  get_globalAngle
  publish_tf
  imu_angle_bridge
  DESTINATION lib/${PROJECT_NAME}
)

if(BUILD_TESTING)
  find_package(ament_lint_auto REQUIRED)
  set(ament_cmake_copyright_FOUND TRUE)
  set(ament_cmake_cpplint_FOUND TRUE)
  ament_lint_auto_find_test_dependencies()
endif()

ament_package()
