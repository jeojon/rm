#include "rpl_compat.h"
#include "usart.h"

#include <string.h>

typedef char Rplc_Require32BitFloat[(sizeof(float) == 4U) ? 1 : -1];

static RplcSender g_sender = {0U};
static uint8_t g_tx_frame[RPLC_TX_FRAME_CAPACITY];

typedef struct
{
    uint16_t command_id;
    size_t payload_length;
} RplcPacketFormat_t;


//命令 ID 与 payload 长度对照表
static const RplcPacketFormat_t g_packet_formats[] =
{
    {RPL_CMD_GIMBAL_VALUE, sizeof(GimbalValuePacket_t)}
};
/**
 * @brief 初始化发送序号
 *
 * @param sender 发送序号指针
 * @param initial_sequence 初始序号
 */
void RplcSender_Init(RplcSender *sender, uint8_t initial_sequence)
{
    if (sender != NULL)
    {
        sender->sequence = initial_sequence;
    }
}

/**
 * @brief 计算 CRC8 校验码
 *
 * @param data 数据指针
 * @param length 数据长度
 * @return uint8_t CRC8 校验码
 */
uint8_t Rplc_Crc8(const uint8_t *data, size_t length)
{
    uint8_t crc = 0xFFU;
    size_t i;
    uint8_t bit;

    for (i = 0U; i < length; ++i)
    {
        crc ^= data[i];
        for (bit = 0U; bit < 8U; ++bit)
        {
            crc = (crc & 0x01U) ?
                (uint8_t)((crc >> 1U) ^ 0x8CU) :
                (uint8_t)(crc >> 1U);
        }
    }

    return crc;
}

/**
 * @brief 计算 CRC16 校验码
 *
 * @param data 数据指针
 * @param length 数据长度
 * @return uint16_t CRC16 校验码
 */
uint16_t Rplc_Crc16(const uint8_t *data, size_t length)
{
    uint16_t crc = 0xFFFFU;
    size_t i;
    uint8_t bit;

    for (i = 0U; i < length; ++i)
    {
        crc ^= data[i];
        for (bit = 0U; bit < 8U; ++bit)
        {
            crc = (crc & 0x0001U) ?
                (uint16_t)((crc >> 1U) ^ 0x8408U) :
                (uint16_t)(crc >> 1U);
        }
    }

    return crc;
}
/**
 * @brief 计算完整帧大小，或当负载过大时返回 0
 * @param payload_length 负载数据长度
 * @return 完整帧大小，或当负载过大时返回 0
 */
size_t Rplc_FrameSize(size_t payload_length)
{
    if (payload_length > (size_t)RPLC_MAX_PAYLOAD_SIZE)
    {
        return 0U;
    }

    return (size_t)RPLC_HEADER_SIZE + payload_length +
        (size_t)RPLC_TAIL_SIZE;
}

/**
 * @brief 打包一个 RPL 帧（底层初始打包函数）
 *
 * @param command_id 命令 ID
 * @param sequence 序号
 * @param payload 负载数据指针
 * @param payload_length 负载数据长度
 * @param frame_buffer 帧缓冲区指针
 * @param frame_capacity 帧缓冲区容量
 * @param frame_length 帧长度指针
 * @return RplcStatus 状态码
 */
RplcStatus Rplc_Pack(
    uint16_t command_id,
    uint8_t sequence,
    const void *payload,
    size_t payload_length,
    uint8_t *frame_buffer,
    size_t frame_capacity,
    size_t *frame_length)
{
    size_t total_length;
    uint16_t crc16;

    if ((frame_buffer == NULL) || (frame_length == NULL) ||
        ((payload == NULL) && (payload_length != 0U)))
    {
        return RPLC_ERROR_ARGUMENT;
    }

    if (payload_length > (size_t)RPLC_MAX_PAYLOAD_SIZE)
    {
        return RPLC_ERROR_PAYLOAD_TOO_LARGE;
    }

    total_length = Rplc_FrameSize(payload_length);
    if (frame_capacity < total_length)
    {
        return RPLC_ERROR_BUFFER_TOO_SMALL;
    }

    frame_buffer[0] = RPLC_START_BYTE;
    frame_buffer[1] = (uint8_t)(payload_length & 0xFFU);
    frame_buffer[2] = (uint8_t)((payload_length >> 8U) & 0xFFU);
    frame_buffer[3] = sequence;
    frame_buffer[4] = Rplc_Crc8(frame_buffer, 4U);
    frame_buffer[5] = (uint8_t)(command_id & 0xFFU);
    frame_buffer[6] = (uint8_t)((command_id >> 8U) & 0xFFU);

    if (payload_length != 0U)
    {
        memcpy(frame_buffer + RPLC_HEADER_SIZE, payload, payload_length);
    }

    crc16 = Rplc_Crc16(
        frame_buffer,
        (size_t)RPLC_HEADER_SIZE + payload_length);
    frame_buffer[RPLC_HEADER_SIZE + payload_length] =
        (uint8_t)(crc16 & 0xFFU);
    frame_buffer[RPLC_HEADER_SIZE + payload_length + 1U] =
        (uint8_t)((crc16 >> 8U) & 0xFFU);

    *frame_length = total_length;
    return RPLC_OK;
}


/**
 * @brief：有序号的打包函数，内部自动维护序号，发送成功后序号+1
 * @param：sender - 序号指针
 * @param：command_id - 命令 ID
 * @param：payload - 负载数据指针
 * @param：payload_length - 负载数据长度
 * @param：frame_buffer - 帧缓冲区指针
 * @param：frame_capacity - 帧缓冲区容量
 * @param：frame_length - 帧长度指针
 * @return：RplcStatus - 状态码
 */
RplcStatus RplcSender_PackPacket(
    RplcSender *sender,
    uint16_t command_id,
    const void *payload,
    size_t payload_length,
    uint8_t *frame_buffer,
    size_t frame_capacity,
    size_t *frame_length)
{
    RplcStatus status;

    if ((sender == NULL) || (payload == NULL))
    {
        return RPLC_ERROR_ARGUMENT;
    }

    status = Rplc_Pack(
        command_id,
        sender->sequence,
        payload,
        payload_length,
        frame_buffer,
        frame_capacity,
        frame_length);

    if (status == RPLC_OK)
    {
        ++sender->sequence;
    }

    return status;
}

/**
 * @brief 发送一个维护序号的 RPL 帧
 *
 * @param sender 序号指针
 * @param command_id 命令 ID
 * @param payload 负载数据指针
 * @param payload_length 负载数据长度
 * @return RplcStatus 状态码
 */
RplcStatus RplcSender_SendPacket(
    RplcSender *sender,
    uint16_t command_id,
    const void *payload,
    size_t payload_length)
{
    size_t frame_length = 0U;
    RplcStatus status;

    status = RplcSender_PackPacket(
        sender,
        command_id,
        payload,
        payload_length,
        g_tx_frame,
        sizeof(g_tx_frame),
        &frame_length);

    if (status != RPLC_OK)
    {
        return status;
    }

    if (HAL_UART_Transmit(
            RPL_UART_HANDLE,
            g_tx_frame,
            (uint16_t)frame_length,
            RPLC_TX_TIMEOUT_MS) != HAL_OK)
    {
        return RPLC_ERROR_UART;
    }

    return RPLC_OK;
}

/**
 * @brief 发送一个 RPL 帧，根据命令id自动查找 payload 长度
 *
 * @param command_id 命令 ID
 * @param payload 负载数据指针
 * @return RplcStatus 状态码
 */
RplcStatus send_packet(
    uint16_t command_id,
    const void *payload)
{
    size_t payload_length = 0U;
    size_t i;

    if (payload == NULL)
    {
        return RPLC_ERROR_ARGUMENT;
    }

    for (i = 0U;
         i < (sizeof(g_packet_formats) / sizeof(g_packet_formats[0]));
         ++i)
    {
        if (g_packet_formats[i].command_id == command_id)
        {
            payload_length = g_packet_formats[i].payload_length;
            break;
        }
    }

    if (payload_length == 0U)
    {
        return RPLC_ERROR_UNSUPPORTED_COMMAND;
    }

    return RplcSender_SendPacket(
        &g_sender,
        command_id,
        payload,
        payload_length);
}

RplcStatus SendGimbalValue(const GimbalValuePacket_t *packet)
{
    return send_packet(RPL_CMD_GIMBAL_VALUE, packet);
}

