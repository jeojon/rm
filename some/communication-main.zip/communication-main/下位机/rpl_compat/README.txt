RPL 按命令 ID 发送模块使用说明
==============================

本目录提供 STM32 使用的 C99 RPL 发送模块。帧格式与上位机 RPL.hpp 兼容。

当前实现已经按命令 ID 发送：

    send_packet(command_id, payload)
        -> 在 g_packet_formats[] 中查找命令号
        -> 取得该命令的 payload 长度
        -> RplcSender_PackPacket()
        -> HAL_UART_Transmit()

不同命令使用各自的数据结构和长度，不要求所有发送数据共用一个固定结构体。


1. 文件与串口
-------------

加入 Keil 工程：

    rpl_compat.c
    rpl_compat.h

头文件搜索路径：

    MDK-ARM/rpl_compat

当前串口配置：

    RPL_UART_HANDLE    = &huart8
    RPL_UART_INSTANCE  = UART8
    波特率              115200
    数据位              8
    校验位              无
    停止位              1

需要更换串口时，在工程编译宏或 rpl_compat.h 中修改
RPL_UART_HANDLE 和 RPL_UART_INSTANCE，并确认对应 UART、GPIO 和时钟已经
初始化。


2. 当前命令与数据结构
---------------------

    RPL_CMD_CONTROL       0x0200
        ControlPacket_t
        float angle_yaw
        float angle_pitch
        8 字节

    RPL_CMD_FIRE          0x0201
        FirePacket_t
        bool fire
        1 字节

    RPL_CMD_GIMBAL_VALUE  0x0300
        GimbalValuePacket_t
        float value
        4 字节

方向约定：

    0x0200 - 0x02FF：上位机 -> 下位机
    0x0300 - 0x03FF：下位机 -> 上位机

当前 ControlPacket_t 和 FirePacket_t 由下位机接收模块接收。当前下位机
发送模块只登记了 GimbalValuePacket_t：

    static const RplcPacketFormat_t g_packet_formats[] =
    {
        {RPL_CMD_GIMBAL_VALUE, sizeof(GimbalValuePacket_t)}
    };

未在 g_packet_formats[] 中登记的命令会返回
RPLC_ERROR_UNSUPPORTED_COMMAND。


3. 常用发送函数
---------------

3.1 按命令 ID 发送

    RplcStatus send_packet(
        uint16_t command_id,
        const void *payload);

功能：

    1. 根据 command_id 在 g_packet_formats[] 中查找 payload 长度。
    2. 使用模块内部发送序号。
    3. 打包一个 RPL 帧。
    4. 通过 RPL_UART_HANDLE 阻塞发送。

示例：

    GimbalValuePacket_t feedback;
    feedback.value = 12.5f;

    RplcStatus status =
        send_packet(RPL_CMD_GIMBAL_VALUE, &feedback);

    if (status != RPLC_OK)
    {
        /* 处理发送失败 */
    }

payload 的实际类型必须与 command_id 对应的协议类型一致。

3.2 发送云台反馈

    RplcStatus SendGimbalValue(
        const GimbalValuePacket_t *packet);

内部等价于：

    return send_packet(RPL_CMD_GIMBAL_VALUE, packet);

示例：

    GimbalValuePacket_t feedback = {0.0f};
    feedback.value = 12.5f;

    (void)SendGimbalValue(&feedback);

函数返回 RplcStatus，成功为 RPLC_OK。

3.3 指定长度发送

    RplcStatus RplcSender_SendPacket(
        RplcSender *sender,
        uint16_t command_id,
        const void *payload,
        size_t payload_length);

该接口直接使用调用者传入的 payload_length，不查询命令表，适合已经确认
长度的情况。

3.4 只打包，不发送

    RplcStatus RplcSender_PackPacket(
        RplcSender *sender,
        uint16_t command_id,
        const void *payload,
        size_t payload_length,
        uint8_t *frame_buffer,
        size_t frame_capacity,
        size_t *frame_length);

如果后续需要使用 DMA 发送，可以先打包到调用者持有的缓冲区，再把帧交给
DMA。DMA 发送完成前不能修改该缓冲区。

3.5 底层无状态打包

    RplcStatus Rplc_Pack(
        uint16_t command_id,
        uint8_t sequence,
        const void *payload,
        size_t payload_length,
        uint8_t *frame_buffer,
        size_t frame_capacity,
        size_t *frame_length);

Rplc_Pack() 不维护发送序号，需要调用者自行提供 sequence。


4. 新增下位机发送数据类型
-------------------------

以下示例增加 BatteryStatus，命令号为 0x0301。

4.1 定义串口结构体

在 rpl_compat.h 中定义：

    typedef __packed struct
    {
        float voltage;
        float current;
    } BatteryStatusPacket_t;

必须与上位机同名串口载荷完全一致：

    字段顺序相同
    字段类型和大小相同
    字节序相同
    填充方式相同

建议增加大小检查：

    typedef char Rplc_BatteryStatusPacketSizeCheck[
        (sizeof(BatteryStatusPacket_t) == 8U) ? 1 : -1];

4.2 增加命令号

在 rpl_compat.h 中增加：

    #define RPL_CMD_BATTERY_STATUS 0x0301U

不能与已有命令号重复。

4.3 登记 payload 长度

在 rpl_compat.c 的 g_packet_formats[] 中增加：

    {RPL_CMD_BATTERY_STATUS, sizeof(BatteryStatusPacket_t)}

修改后：

    static const RplcPacketFormat_t g_packet_formats[] =
    {
        {RPL_CMD_GIMBAL_VALUE, sizeof(GimbalValuePacket_t)},
        {RPL_CMD_BATTERY_STATUS, sizeof(BatteryStatusPacket_t)}
    };

4.4 调用发送函数

    BatteryStatusPacket_t status_packet;
    status_packet.voltage = 24.0f;
    status_packet.current = 1.5f;

    (void)send_packet(
        RPL_CMD_BATTERY_STATUS,
        &status_packet);

也可以封装专用函数：

    RplcStatus SendBatteryStatus(
        const BatteryStatusPacket_t *packet)
    {
        return send_packet(RPL_CMD_BATTERY_STATUS, packet);
    }

4.5 上位机同步修改

上位机需要：

    1. 新增 interface/msg/BatteryStatus.msg。
    2. 在 interface/CMakeLists.txt 注册消息。
    3. 定义相同布局的 packed 载荷。
    4. 增加 PacketTraits，cmd = 0x0301。
    5. 加入 Deserializer、Parser、rx_bindings。
    6. 创建 Publisher 并转换成 ROS 消息。

下位机只需要在 g_packet_formats[] 中登记一次，不需要为每个命令新增独立的
pack 或 parse 分支。


5. 修改已有发送数据
-------------------

修改 GimbalValuePacket_t 时，payload 长度会通过
sizeof(GimbalValuePacket_t) 自动更新。仍必须检查：

    1. 上位机串口结构体同步修改。
    2. 上位机 PacketTraits::size 同步生效。
    3. 上位机字段转换代码同步修改。
    4. 增加或更新编译期大小检查。
    5. 命令号保持不变，除非协议有意升级。

如果命令号不变但结构体长度改变，新旧固件和上位机不能混用。


6. 发送缓冲区和调用限制
-----------------------

RplcSender_SendPacket() 使用模块内部静态缓冲：

    static uint8_t g_tx_frame[RPLC_TX_FRAME_CAPACITY];

因此不要从多个任务或多个中断同时调用发送函数。建议只在单一控制任务或
主循环中发送。

当前 HAL_UART_Transmit() 是阻塞发送。高频发送时应该评估阻塞时间，或者
改成 DMA，并确保发送完成前缓冲区不会被覆盖。


7. RPL 帧格式
-------------

    A5
    | payload 长度低字节
    | payload 长度高字节
    | sequence
    | CRC8
    | command_id 低字节
    | command_id 高字节
    | payload
    | CRC16 低字节
    | CRC16 高字节

完整帧长度：

    7 + payload_length + 2

帧中的 payload 长度来自对应命令登记的长度，不会再附加其他命令的数据。


8. 常见问题
-----------

返回 RPLC_ERROR_UNSUPPORTED_COMMAND：

    检查 command_id 是否已经加入 g_packet_formats[]。

返回 RPLC_ERROR_ARGUMENT：

    检查 sender、payload 是否为 NULL。

上位机 CRC 校验失败：

    检查两端结构体大小、字段顺序、packed 属性和命令号是否一致。

上位机收不到数据：

    检查 RPL_UART_HANDLE、波特率、TX/RX 接线和共地。

命令能打包但数据字段错误：

    检查传入 payload 的实际类型是否与 command_id 匹配。

