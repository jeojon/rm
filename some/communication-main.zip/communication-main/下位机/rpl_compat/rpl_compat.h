/**
 * @file rpl_compat.h
 * @brief Small RPL-compatible packet sender for C99 and C++11.
 *
 * This file only implements the default RPL wire format used by RPL.hpp:
 *
 *   A5 | length LE (2) | sequence | header CRC8 |
 *   command LE (2) | payload | frame CRC16 LE (2)
 */

#ifndef RPL_COMPAT_H
#define RPL_COMPAT_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef RPL_UART_HANDLE
#define RPL_UART_HANDLE        (&huart8)
#endif

#ifndef RPL_UART_INSTANCE
#define RPL_UART_INSTANCE      UART8
#endif

#define RPLC_START_BYTE       0xA5U
#define RPLC_HEADER_SIZE      7U
#define RPLC_TAIL_SIZE        2U
#define RPLC_MAX_PAYLOAD_SIZE 0xFFFFU
#define RPLC_TX_FRAME_CAPACITY 64U
#define RPLC_TX_TIMEOUT_MS     10U

/* Command IDs and their payload structures form the application protocol. */
#define RPL_CMD_CONTROL        0x0200U
#define RPL_CMD_ANGLE          RPL_CMD_CONTROL
#define RPL_CMD_FIRE           0x0201U
#define RPL_CMD_GIMBAL_VALUE   0x0300U

typedef __packed struct
{
    float angle_yaw;
    float angle_pitch;
} ControlPacket_t;

typedef __packed struct
{
    bool fire;
} FirePacket_t;

typedef __packed struct
{
    float value;
} GimbalValuePacket_t;

/* C++ code can use the shorter names in PacketTraits specializations. */
typedef ControlPacket_t ControlPacket;
typedef FirePacket_t FirePacket;
typedef GimbalValuePacket_t GimbalValuePacket;

/* Keep the old sender type name usable while the new API is adopted. */
typedef GimbalValuePacket_t RplcTxData_t;

typedef char Rplc_ControlPacketSizeCheck[
    (sizeof(ControlPacket_t) == 8U) ? 1 : -1];
typedef char Rplc_FirePacketSizeCheck[
    (sizeof(FirePacket_t) == 1U) ? 1 : -1];
typedef char Rplc_GimbalValuePacketSizeCheck[
    (sizeof(GimbalValuePacket_t) == 4U) ? 1 : -1];

typedef enum
{
    RPLC_OK = 0,
    RPLC_ERROR_ARGUMENT,
    RPLC_ERROR_BUFFER_TOO_SMALL,
    RPLC_ERROR_PAYLOAD_TOO_LARGE,
    RPLC_ERROR_UNSUPPORTED_COMMAND,
    RPLC_ERROR_UART
} RplcStatus;

typedef struct
{
    uint8_t sequence;
} RplcSender;

#define RPLC_TX_FRAME_SIZE \
    ((size_t)RPLC_HEADER_SIZE + sizeof(RplcTxData_t) + (size_t)RPLC_TAIL_SIZE)
#define RPLC_CONTROL_FRAME_SIZE \
    ((size_t)RPLC_HEADER_SIZE + sizeof(ControlPacket_t) + (size_t)RPLC_TAIL_SIZE)
#define RPLC_FIRE_FRAME_SIZE \
    ((size_t)RPLC_HEADER_SIZE + sizeof(FirePacket_t) + (size_t)RPLC_TAIL_SIZE)
#define RPLC_GIMBAL_VALUE_FRAME_SIZE \
    ((size_t)RPLC_HEADER_SIZE + sizeof(GimbalValuePacket_t) + (size_t)RPLC_TAIL_SIZE)

void RplcSender_Init(RplcSender *sender, uint8_t initial_sequence);

uint8_t Rplc_Crc8(const uint8_t *data, size_t length);
uint16_t Rplc_Crc16(const uint8_t *data, size_t length);

/**
 * @brief Return the complete frame size, or 0 when the payload is too large.
 */
size_t Rplc_FrameSize(size_t payload_length);

/**
 * @brief Pack any payload into one RPL-compatible frame.
 *
 * Payload bytes are copied unchanged. The caller is responsible for matching
 * its byte order and structure layout with the upper computer.
 */
RplcStatus Rplc_Pack(
    uint16_t command_id,
    uint8_t sequence,
    const void *payload,
    size_t payload_length,
    uint8_t *frame_buffer,
    size_t frame_capacity,
    size_t *frame_length);

/**
 * @brief Pack one command payload into an RPL frame.
 *
 * Only the selected payload is copied, so unrelated packet types do not add
 * bytes to this frame. The sequence number increments after a successful pack.
 */
RplcStatus RplcSender_PackPacket(
    RplcSender *sender,
    uint16_t command_id,
    const void *payload,
    size_t payload_length,
    uint8_t *frame_buffer,
    size_t frame_capacity,
    size_t *frame_length);

/**
 * @brief Pack and transmit one command payload using a caller-owned sender.
 */
RplcStatus RplcSender_SendPacket(
    RplcSender *sender,
    uint16_t command_id,
    const void *payload,
    size_t payload_length);

/**
 * @brief Send a registered packet by command ID.
 *
 * The command ID selects the payload structure and therefore its frame length.
 * The lower computer currently sends RPL_CMD_GIMBAL_VALUE with a
 * GimbalValuePacket_t payload.
 */
RplcStatus send_packet(
    uint16_t command_id,
    const void *payload);

RplcStatus SendGimbalValue(const GimbalValuePacket_t *packet);

#ifdef __cplusplus
}
#endif

#endif /* RPL_COMPAT_H */
