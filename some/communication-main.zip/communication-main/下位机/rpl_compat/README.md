# RPL Command-ID Sender

This directory contains the STM32 C99 RPL sender used by the lower computer.
It implements the same wire format as the upper-computer `RPL.hpp`.

## Command-ID routing

`send_packet(command_id, payload)` looks up the payload size in
`g_packet_formats[]`, packs one RPL frame, and sends it through
`RPL_UART_HANDLE`.

Current protocol:

| Direction | Command | C type | Payload |
| --- | ---: | --- | ---: |
| Upper to lower | `0x0200` | `ControlPacket_t` | 8 bytes |
| Upper to lower | `0x0201` | `FirePacket_t` | 1 byte |
| Lower to upper | `0x0300` | `GimbalValuePacket_t` | 4 bytes |

The sender currently registers only `RPL_CMD_GIMBAL_VALUE` in
`g_packet_formats[]`. Commands not present in the table return
`RPLC_ERROR_UNSUPPORTED_COMMAND`.

## Send an existing packet

```c
#include "rpl_compat.h"

void SendCurrentValue(float value)
{
    GimbalValuePacket_t packet = {value};

    (void)SendGimbalValue(&packet);
}
```

The generic form is:

```c
RplcStatus status = send_packet(RPL_CMD_GIMBAL_VALUE, &packet);
```

`RplcSender_SendPacket()` accepts an explicit payload length.
`RplcSender_PackPacket()` packs without transmitting.

## Add a new lower-to-upper packet

1. Define a packed structure in `rpl_compat.h`.
2. Add a unique command ID in the `0x0300` to `0x03FF` range.
3. Add `{ command_id, sizeof(PacketType) }` to `g_packet_formats[]`.
4. Call `send_packet(command_id, &payload)`.
5. Mirror the packed structure, command ID, RPL parser, and ROS publisher on
   the upper computer.

Example:

```c
typedef __packed struct
{
    float voltage;
    float current;
} BatteryStatusPacket_t;

#define RPL_CMD_BATTERY_STATUS 0x0301U
```

```c
static const RplcPacketFormat_t g_packet_formats[] =
{
    {RPL_CMD_GIMBAL_VALUE, sizeof(GimbalValuePacket_t)},
    {RPL_CMD_BATTERY_STATUS, sizeof(BatteryStatusPacket_t)}
};
```

```c
BatteryStatusPacket_t packet = {24.0f, 1.5f};
(void)send_packet(RPL_CMD_BATTERY_STATUS, &packet);
```

No separate command-specific pack or transmit function is required. The command
ID determines the payload length and selects the data interpretation on the
receiver.

## Constraints

- The UART currently uses `huart8`.
- The default format is 115200 8N1.
- The internal TX buffer is shared, so call the sender from one task only.
- `HAL_UART_Transmit()` is blocking.
- Lower and upper packed structures must have identical field order, types,
  sizes, and byte order.

