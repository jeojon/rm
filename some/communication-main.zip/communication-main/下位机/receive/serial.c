#include "serial.h"


#include <string.h>





ControlPacket_t control_packet = {0.0f, 0.0f}; // 初始化控制数据结构体
FirePacket_t fire_packet = {false};

static uint8_t rx_dma_buffer[RPL_RX_DMA_SIZE];
static uint8_t frame_buffer[RPL_FRAME_CAPACITY];
static uint16_t frame_length = 0U;

volatile uint8_t control_packet_ready = 0U;
volatile uint8_t fire_packet_ready = 0U;
/**
 * @brief 命令 ID 与数据绑定数组
 */
static const RplPacketBinding_t packet_bindings[] =
{
    {
        RPL_CMD_CONTROL,
        &control_packet,
        sizeof(control_packet),
        &control_packet_ready
    },
    {
        RPL_CMD_FIRE,
        &fire_packet,
        sizeof(fire_packet),
        &fire_packet_ready
    }
};



/**
 * @brief 按帧头中的 payload 长度检查并解析一帧。
 * @param frame 帧数据指针
 * @param frame_length 帧数据长度
 * @param bindings 命令与数据绑定数组
 * @param binding_count 绑定数组个数
 * @return RplParseResult_t 解析结果
 */
RplParseResult_t parse_packet_frame(
    const uint8_t *frame,
    size_t frame_length,
    const RplPacketBinding_t *bindings,
    size_t binding_count)
{
    uint16_t command_id;
    const uint8_t *payload;
    uint16_t parsed_payload_length;
    size_t total_length;
    size_t i;

    if ((frame == NULL) || (bindings == NULL) || (binding_count == 0U)) {
        return RPL_PARSE_ARGUMENT_ERROR;
    }

    if (frame_length < RPLC_HEADER_SIZE) {
        return RPL_PARSE_LENGTH_ERROR;
    }

    if (frame[0] != RPLC_START_BYTE) {
        return RPL_PARSE_LENGTH_ERROR;
    }

    parsed_payload_length =
        (uint16_t)frame[1] |
        ((uint16_t)frame[2] << 8U);

    total_length = Rplc_FrameSize(parsed_payload_length);
    if (frame_length < total_length) {
        return RPL_PARSE_LENGTH_ERROR;
    }

    if (Rplc_Crc8(frame, 4U) != frame[4]) {
        return RPL_PARSE_CRC8_ERROR;
    }

    command_id =
        (uint16_t)frame[5] |
        ((uint16_t)frame[6] << 8U);
    if (Rplc_Crc16(frame, total_length - RPLC_TAIL_SIZE) !=
        ((uint16_t)frame[total_length - 2] |
         ((uint16_t)frame[total_length - 1] << 8U))) {
        return RPL_PARSE_CRC16_ERROR;
    }

    payload = frame + RPLC_HEADER_SIZE;

    for (i = 0U; i < binding_count; ++i) {
        if (bindings[i].command_id == command_id) {
            if (parsed_payload_length != bindings[i].payload_length) {
                return RPL_PARSE_LENGTH_ERROR;
            }
            if ((bindings[i].destination == NULL) ||
                (bindings[i].ready_flag == NULL)) {
                return RPL_PARSE_ARGUMENT_ERROR;
            }

            memcpy(
                bindings[i].destination,
                payload,
                parsed_payload_length);
            *bindings[i].ready_flag = 1U;
            return RPL_PARSE_OK;
        }
    }

    return RPL_PARSE_CMD_ERROR;
}

/**
 * @brief 在接收错误后尝试重新同步到下一个帧头。
 */
static void rpl_resync_after_error(void)
{
    uint16_t next_start = frame_length;

    for (uint16_t i = 1U; i < frame_length; ++i) {
        if (frame_buffer[i] == RPLC_START_BYTE) {
            next_start = i;
            break;
        }
    }

    if (next_start < frame_length) {
        frame_length = (uint16_t)(frame_length - next_start);
        memmove(frame_buffer, &frame_buffer[next_start], frame_length);
    } else {
        frame_length = 0U;
    }
}

/**
 * @brief 从连续字节流中按帧头长度提取一帧。
 * @param data 字节流数据指针
 * @param length 字节流数据长度
 */
static void rpl_feed_bytes(
    const uint8_t *data,
    uint16_t length)
{
    for (uint16_t i = 0U; i < length ; ++i) {
        const uint8_t byte = data[i];

        /* 等待帧头 */
        if ((frame_length == 0U) &&
            (byte != RPLC_START_BYTE)) {
            continue;
        }

        frame_buffer[frame_length++] = byte;

        /* 至少收到 3 个字节后才能知道 payload 长度。 */
        if (frame_length < 3U) {
            continue;
        }

        {
            const uint16_t payload_length =
                (uint16_t)frame_buffer[1] |
                ((uint16_t)frame_buffer[2] << 8U);
            const size_t expected_length =
                Rplc_FrameSize(payload_length);

            if (expected_length > RPL_FRAME_CAPACITY) {
                rpl_resync_after_error();
                continue;
            }

            if (frame_length < expected_length) {
                continue;
            }

            {
                const RplParseResult_t parse_result = parse_packet_frame(
                    frame_buffer,
                    expected_length,
                    packet_bindings,
                    sizeof(packet_bindings) / sizeof(packet_bindings[0]));

                if (parse_result == RPL_PARSE_OK) {
                    frame_length = 0U;
                } else {
                    rpl_resync_after_error();
                }
            }
        }
    }
}



/**
 * @brief 启动UART DMA接收
 */
void rpl_uart_dma_start(void)
{
    (void)HAL_UARTEx_ReceiveToIdle_DMA(
        RPL_UART_HANDLE,
        rx_dma_buffer,
        RPL_RX_DMA_SIZE);
}

/**
 * @brief UART接收事件回调函数
 * @param huart UART句柄
 * @param Size 接收数据长度
 */
void HAL_UARTEx_RxEventCallback(
    UART_HandleTypeDef *huart,
    uint16_t Size)
{   
    if (huart->Instance == RPL_UART_INSTANCE) {
        if (Size > RPL_RX_DMA_SIZE) {
            Size = RPL_RX_DMA_SIZE;
        }

        rpl_feed_bytes(rx_dma_buffer, Size);

        (void)HAL_UARTEx_ReceiveToIdle_DMA(
            RPL_UART_HANDLE,
            rx_dma_buffer,
            RPL_RX_DMA_SIZE);
    }
}
