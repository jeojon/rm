#ifndef SERIAL_H
#define SERIAL_H

#include "usart.h"
#include "rpl_compat.h"
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define RPL_RX_DMA_SIZE 128U //DMA接收缓冲区大小

#ifndef RPL_UART_HANDLE
#define RPL_UART_HANDLE        (&huart8)
#endif

#ifndef RPL_UART_INSTANCE
#define RPL_UART_INSTANCE      UART8
#endif

#ifndef RPL_UART_START_DMA
#define RPL_UART_START_DMA(buffer, length) \
    HAL_UART_Receive_DMA(RPL_UART_HANDLE, (buffer), (length))
#endif

#ifndef RPL_UART_ABORT_DMA
#define RPL_UART_ABORT_DMA() \
    HAL_UART_AbortReceive(RPL_UART_HANDLE)
#endif

#ifndef RPL_UART_RX_COMPLETE_CALLBACK
#define RPL_UART_RX_COMPLETE_CALLBACK HAL_UART_RxCpltCallback
#endif

#ifndef RPL_UART_ERROR_CALLBACK
#define RPL_UART_ERROR_CALLBACK HAL_UART_ErrorCallback
#endif
/* Maximum complete RPL frame assembled by the receiver. */
#define RPL_FRAME_CAPACITY    64U

typedef enum {
    RPL_PARSE_OK = 0,
    RPL_PARSE_LENGTH_ERROR,
    RPL_PARSE_CRC8_ERROR,
    RPL_PARSE_CMD_ERROR,
    RPL_PARSE_CRC16_ERROR,
    RPL_PARSE_ARGUMENT_ERROR
} RplParseResult_t;

typedef struct
{
    uint16_t command_id;
    void *destination;
    size_t payload_length;
    volatile uint8_t *ready_flag;
} RplPacketBinding_t;

extern ControlPacket_t control_packet;
extern FirePacket_t fire_packet;
extern volatile uint8_t control_packet_ready;
extern volatile uint8_t fire_packet_ready;

void rpl_uart_dma_start(void);

void HAL_UARTEx_RxEventCallback(
    UART_HandleTypeDef *huart,
    uint16_t Size);

RplParseResult_t parse_packet_frame(
    const uint8_t *frame,
    size_t frame_length,
    const RplPacketBinding_t *bindings,
    size_t binding_count);
#endif // SERIAL_H
