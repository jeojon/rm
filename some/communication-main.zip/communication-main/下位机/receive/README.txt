RPL 按命令 ID 接收模块使用说明
==============================

本目录提供 STM32 UART DMA 接收和 RPL 帧解析模块。

当前接收已经按命令 ID 分发，不再把所有合法帧都解释成 ControlPacket_t。

数据处理流程：

    UART DMA 空闲事件
        -> rpl_feed_bytes()
        -> 从帧头读取 payload 长度
        -> parse_packet_frame()
        -> 校验帧头、长度、CRC8、命令号、CRC16
        -> 在 packet_bindings[] 中查找 command_id
        -> 把 payload 复制到对应结构体
        -> 把对应 ready_flag 置 1


1. 当前支持的命令
-----------------

    RPL_CMD_CONTROL  0x0200
        ControlPacket_t
        目标结构体：control_packet
        ready 标志：control_packet_ready

    RPL_CMD_FIRE     0x0201
        FirePacket_t
        目标结构体：fire_packet
        ready 标志：fire_packet_ready

命令绑定表位于 serial.c：

    static const RplPacketBinding_t packet_bindings[] =
    {
        {
            RPL_CMD_CONTROL,
            &control_packet,
            sizeof(control_packet),
            &control_packet_ready
        },
        {
            RPL_CMD_FIRE,
            &fire_packet,
            sizeof(fire_packet),
            &fire_packet_ready
        }
    };

每条绑定包含：

    command_id
        帧中携带的命令号。

    destination
        解析成功后接收 payload 的目标结构体地址。

    payload_length
        该命令要求的 payload 字节数。

    ready_flag
        收到该命令有效数据后置 1 的标志。


2. 对外接口
-----------

包含：

    #include "serial.h"

启动 UART DMA 接收：

    rpl_uart_dma_start();

应在 UART、GPIO、DMA 和中断初始化完成后调用一次。

当前默认串口：

    RPL_UART_HANDLE    = &huart8
    RPL_UART_INSTANCE  = UART8

UART 空闲事件回调：

    HAL_UARTEx_RxEventCallback(
        UART_HandleTypeDef *huart,
        uint16_t Size);

回调会处理本次 DMA 收到的字节，并重新启动 ReceiveToIdle_DMA。

通用解析接口：

    RplParseResult_t parse_packet_frame(
        const uint8_t *frame,
        size_t frame_length,
        const RplPacketBinding_t *bindings,
        size_t binding_count);

该函数按帧中的命令号查找绑定，不依赖固定的 payload 长度。


3. 在控制代码中读取数据
-----------------------

控制包：

    if (control_packet_ready != 0U)
    {
        ControlPacket_t packet = control_packet;
        control_packet_ready = 0U;

        /* packet.angle_yaw, packet.angle_pitch */
    }

开火包：

    if (fire_packet_ready != 0U)
    {
        FirePacket_t packet = fire_packet;
        fire_packet_ready = 0U;

        /* packet.fire */
    }

读取后应手动清 ready 标志。没有新数据时，目标结构体保持最近一次有效值。


4. 新增下位机接收命令
---------------------

以下示例增加 BatteryCommand，命令号为 0x0202。

4.1 定义结构体

在 rpl_compat.h 中增加：

    typedef __packed struct
    {
        float voltage_limit;
        uint8_t mode;
    } BatteryCommandPacket_t;

字段布局必须与上位机串口载荷完全一致。

建议增加大小检查：

    typedef char Rplc_BatteryCommandPacketSizeCheck[
        (sizeof(BatteryCommandPacket_t) == 5U) ? 1 : -1];

4.2 增加命令号

在 rpl_compat.h 中增加：

    #define RPL_CMD_BATTERY_COMMAND 0x0202U

不要复用已有命令号。

4.3 定义接收变量

在 serial.c 中定义：

    BatteryCommandPacket_t battery_command_packet =
        {0.0f, 0U};

    volatile uint8_t battery_command_ready = 0U;

在 serial.h 中声明：

    extern BatteryCommandPacket_t battery_command_packet;
    extern volatile uint8_t battery_command_ready;

4.4 增加命令绑定

在 packet_bindings[] 中增加：

    {
        RPL_CMD_BATTERY_COMMAND,
        &battery_command_packet,
        sizeof(battery_command_packet),
        &battery_command_ready
    }

绑定表修改后：

    static const RplPacketBinding_t packet_bindings[] =
    {
        {
            RPL_CMD_CONTROL,
            &control_packet,
            sizeof(control_packet),
            &control_packet_ready
        },
        {
            RPL_CMD_FIRE,
            &fire_packet,
            sizeof(fire_packet),
            &fire_packet_ready
        },
        {
            RPL_CMD_BATTERY_COMMAND,
            &battery_command_packet,
            sizeof(battery_command_packet),
            &battery_command_ready
        }
    };

4.5 等待新数据

    if (battery_command_ready != 0U)
    {
        BatteryCommandPacket_t packet =
            battery_command_packet;

        battery_command_ready = 0U;

        /* 使用 packet.voltage_limit 和 packet.mode */
    }

不需要新增专用 parse 函数，也不需要修改命令分发 switch。

4.6 上位机同步修改

上位机需要：

    1. 新增对应 interface/msg 消息。
    2. 注册 rosidl_generate_interfaces()。
    3. 定义相同布局的 packed 串口载荷。
    4. 增加 PacketTraits 和唯一命令号。
    5. 加入 Serializer。
    6. 增加 ROS Subscription、回调、pending 和发送调度。


5. 修改已有接收结构体
---------------------

例如给 ControlPacket_t 增加字段：

    1. 修改 ControlPacket_t。
    2. 同步修改上位机 ControlCommandPacket。
    3. 同步修改 ROS 消息到串口载荷的赋值代码。
    4. 确保协议双方重新编译。

payload 长度使用 sizeof(control_packet) 自动登记，但解析器会把帧头中的
长度与该值比较：

    parsed_payload_length != bindings[i].payload_length

长度不一致时返回 RPL_PARSE_LENGTH_ERROR。


6. 缓冲区限制
-------------

当前完整帧缓冲区容量：

    RPL_FRAME_CAPACITY = 64 bytes

最大 payload：

    64 - 7 字节帧头 - 2 字节 CRC16 = 55 bytes

新增 payload 超过 55 字节时，必须同时提高 RPL_FRAME_CAPACITY，并确认
DMA 接收缓冲区可以容纳连续数据。


7. 解析结果
-----------

    RPL_PARSE_OK
        帧有效，命令已绑定，数据已经复制，ready_flag 已置 1。

    RPL_PARSE_LENGTH_ERROR
        帧头、总长度或 payload 长度不合法。

    RPL_PARSE_CRC8_ERROR
        帧头 CRC8 错误。

    RPL_PARSE_CRC16_ERROR
        整帧 CRC16 错误。

    RPL_PARSE_CMD_ERROR
        命令号没有在 packet_bindings[] 中登记。

    RPL_PARSE_ARGUMENT_ERROR
        指针参数无效，或绑定中的目标地址/ready_flag 为空。

解析失败时接收状态机会尝试从当前帧缓冲区中的下一个 0xA5 重新同步。


8. 注意事项
-----------

1. 接收和发送命令号必须与上位机 PacketTraits 完全一致。
2. 每条命令必须有独立的 payload_length。
3. 不要把不同类型的数据写入同一个目标结构体。
4. 每个绑定应使用独立的 ready_flag。
5. 未知命令不会写入任何业务数据。
6. 修改串口时，UART、GPIO、DMA、中断和上位机设备路径必须同步修改。

