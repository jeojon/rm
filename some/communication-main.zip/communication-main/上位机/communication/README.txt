communication 上位机串口通信使用说明
=====================================

本文档对应 communication 工作空间中的 senddata 和 interface 两个包。

工作空间源码结构：

    communication/
    ├── README.txt
    └── src/
        ├── interface/
        │   ├── CMakeLists.txt
        │   ├── package.xml
        │   └── msg/
        │       ├── Datainterface.msg
        │       ├── FireCommand.msg
        │       └── GimbalValue.msg
        └── senddata/
            ├── CMakeLists.txt
            ├── package.xml
            ├── include/
            │   └── RPL.hpp
            └── src/
                ├── senddata.cpp
                └── li4.cpp


0. 移植建议
-----------

如果只是把本机的新协议移植到 latte，建议只复制：

    senddata/src/senddata.cpp
    senddata/include/RPL.hpp

然后在 latte 本机重新建立 interface 消息和工作空间。latte 主机上原有的
senddata/interface 可能是旧版，可能没有当前使用的新命令号。

完整移植时，interface/msg 中的消息定义和 senddata 必须一起更新，不能只
替换 senddata.cpp。

当前上下位机都已按命令 ID 路由。下位机发送使用
rpl_compat.c 中的 g_packet_formats[]，下位机接收使用 receive/serial.c
中的 packet_bindings[]。移植新协议时也必须同步更新这两个命令表。


1. 当前功能
-----------

senddata 节点通过同一个 Linux 串口完成两个方向的数据通信。

上位机 -> 下位机：

    /angle_data
        interface::msg::Datainterface
        -> ControlCommandPacket
        -> RPL 序列化
        -> 串口发送

    /fire_command
        interface::msg::FireCommand
        -> FireCommandPacket
        -> RPL 序列化
        -> 串口发送

下位机 -> 上位机：

    串口接收
        -> RPL::Parser
        -> GimbalValuePacket
        -> interface::msg::GimbalValue
        -> /gimbal_value

通信参数：

    串口波特率：115200
    数据位：8
    校验位：无
    停止位：1
    流控：无


2. 实际使用方式
---------------

senddata 是 ROS 2 节点。其他程序通常不需要直接调用 senddata.cpp 中的 C++
函数，只需要发布或订阅相应 ROS 话题。

2.1 启动节点

    source /opt/ros/<ROS_DISTRO>/setup.bash
    source ~/communication/install/setup.bash
    ros2 run senddata senddata

2.2 发送云台目标角度

发布 interface::msg::Datainterface 到 /angle_data：

    ros2 topic pub --once /angle_data interface/msg/Datainterface \
      "{angle_yaw: 1.0, angle_pitch: 0.5}"

Datainterface.msg：

    float64 angle_yaw
    float64 angle_pitch

ROS 消息中的角度使用 double。转换为 ControlCommandPacket 时，会赋值给
float 字段，因此串口传输的是 32 位浮点数。

2.3 发送开火命令

开始开火：

    ros2 topic pub --once /fire_command interface/msg/FireCommand \
      "{fire: true}"

停止开火：

    ros2 topic pub --once /fire_command interface/msg/FireCommand \
      "{fire: false}"

FireCommand.msg：

    bool fire

2.4 接收下位机云台数据

订阅 /gimbal_value：

    ros2 topic echo /gimbal_value

GimbalValue.msg：

    float32 value

2.5 使用测试发布节点

li4_node 会每秒向 /angle_data 发布一次测试角度：

    ros2 run senddata li4_node

2.6 当前发送策略

senddata 在以下情况才发送新帧：

    - 第一次收到 /angle_data
    - angle_yaw 或 angle_pitch 发生变化
    - 第一次收到 /fire_command
    - fire 从 false 变为 true，或从 true 变为 false

重复发布完全相同的角度或开火状态不会重复发送。需要周期重发时，必须修改
senddata.cpp 中的 send_packet() 调度逻辑。


3. 源码中的实际函数
-------------------

3.1 上位机节点 senddata.cpp

callback_control_command(
    const interface::msg::Datainterface::SharedPtr)

    功能：接收 /angle_data，将 ROS 消息转换成 ControlCommandPacket。
    位置：getnode 类。

callback_fire_command(
    const interface::msg::FireCommand::SharedPtr)

    功能：接收 /fire_command，将 ROS 消息转换成 FireCommandPacket。
    位置：getnode 类。

template <typename Packet>
bool send_packet(const Packet &packet)

    功能：序列化一个指定类型的串口载荷，并调用 serial_send() 写串口。
    注意：Packet 类型必须已经加入 RPL::Serializer 模板参数列表。

void send_packet()

    功能：发送调度函数。检查 control_pending_ 和 fire_pending_，决定本次
    是否发送控制包或开火包。
    注意：新增发送类型时，必须同步扩展这个函数。

void receive_packets()

    功能：非阻塞读取串口，把收到的字节送入 rx_parser_.push_data()。

void process_received_packets()

    功能：遍历 rx_bindings，检查每个接收类型的 deserializer version，
    发现新数据时调用对应处理 lambda。

rx_bindings

    功能：接收数据类型注册表。当前只有 GimbalValuePacket 一个条目。
    新增下位机上传类型时，需要增加数组长度并增加处理条目。

3.2 下位机收发接口

send_packet(uint16_t command_id, const void *payload)

    功能：根据 command_id 查找载荷长度，并使用内部 sender 打包发送。
    命令号和载荷长度必须在 g_packet_formats[] 中登记。

SendGimbalValue(const GimbalValuePacket_t *packet)

    功能：发送云台反馈数据，内部调用：

    send_packet(RPL_CMD_GIMBAL_VALUE, packet);

下位机调用示例：

    GimbalValuePacket_t feedback;
    feedback.value = 1.25f;

    RplcStatus status = SendGimbalValue(&feedback);
    if (status != RPLC_OK)
    {
        /* 记录或处理发送失败 */
    }

parse_packet_frame(
    const uint8_t *frame,
    size_t frame_length,
    const RplPacketBinding_t *bindings,
    size_t binding_count)

    功能：校验 RPL 帧，读取帧中的命令 ID，在 packet_bindings[] 中查找
    对应目标结构体、payload 长度和 ready 标志。
    修改位置：下位机 receive/serial.c。

rpl_uart_dma_start()

    功能：启动 UART DMA 空闲中断接收。

g_packet_formats[]

    下位机发送命令表。每一项包含 command_id 和 payload_length。
    send_packet() 通过该表决定当前命令应发送多少字节。

packet_bindings[]

    下位机接收命令表。每一项包含 command_id、目标结构体地址、
    payload_length 和 ready_flag。
    parse_packet_frame() 解析成功后，把 payload 复制到对应目标结构体。


4. 当前协议
-----------

方向                 ROS 消息                      串口载荷               命令号
-------------------------------------------------------------------------------
上位机 -> 下位机    interface/msg/Datainterface   ControlCommandPacket   0x0200
上位机 -> 下位机    interface/msg/FireCommand     FireCommandPacket      0x0201
下位机 -> 上位机    interface/msg/GimbalValue     GimbalValuePacket      0x0300

接收和发送都以命令 ID 区分数据类型：

    上位机接收
        RPL::Parser -> PacketTraits -> rx_bindings

    下位机接收
        parse_packet_frame() -> packet_bindings[]

    下位机发送
        send_packet() -> g_packet_formats[]

增加新命令时，不需要修改统一的帧头解析流程，只需要登记对应命令的数据结构
和 payload 长度。

串口载荷定义：

    #pragma pack(push, 1)

    struct ControlCommandPacket {
        float angle_yaw;
        float angle_pitch;
    };

    struct FireCommandPacket {
        bool fire;
    };

    struct GimbalValuePacket {
        float value;
    };

    #pragma pack(pop)

载荷大小：

    ControlCommandPacket：8 字节
    FireCommandPacket：1 字节
    GimbalValuePacket：4 字节

RPL 帧格式：

    A5
    | 数据长度低字节
    | 数据长度高字节
    | 序列号
    | CRC8
    | 命令号低字节
    | 命令号高字节
    | 载荷
    | CRC16 低字节
    | CRC16 高字节

完整帧长度：

    7 字节帧头 + 载荷长度 + 2 字节 CRC16


5. 编译和运行
-------------

进入工作空间：

    cd ~/communication

加载 ROS 2：

    source /opt/ros/<ROS_DISTRO>/setup.bash

构建自定义接口和发送节点：

    colcon build --packages-up-to senddata --event-handlers console_direct+

加载本次构建结果：

    source ~/communication/install/setup.bash

确认消息生成：

    ros2 interface show interface/msg/Datainterface
    ros2 interface show interface/msg/FireCommand
    ros2 interface show interface/msg/GimbalValue

确认可执行文件：

    ros2 pkg executables senddata

运行：

    ros2 run senddata senddata

修改 .msg、包名、CMakeLists.txt 或 C++ 代码后，必须重新执行 colcon build
并重新 source 工作空间。


6. 串口设备配置
---------------

当前串口路径在 senddata.cpp 中：

    static constexpr const char* SERIAL_DEVICE =
        "/dev/serial/by-id/usb-1a86_USB_Serial-if00-port0";

查看实际设备：

    ls -l /dev/serial/by-id/
    ls -l /dev/ttyUSB*
    ls -l /dev/ttyACM*

如果路径不同，修改 SERIAL_DEVICE 后重新编译 senddata。

串口权限不足时：

    sudo usermod -aG dialout $USER

重新登录终端后生效。

注意：open() 成功只说明设备文件已打开，不代表下位机正在发送有效数据。
还需要通过 /gimbal_value 或串口帧校验确认实际通信正常。


7. 新增上位机 -> 下位机数据类型
-------------------------------

以下步骤实现一个新的发送类型，例如 BatteryCommand。

7.1 新增 ROS 消息

创建：

    src/interface/msg/BatteryCommand.msg

内容示例：

    float32 voltage_limit
    uint8 mode

7.2 注册 ROS 消息

修改 src/interface/CMakeLists.txt，把新消息加入已有列表：

    rosidl_generate_interfaces(${PROJECT_NAME}
      "msg/Datainterface.msg"
      "msg/FireCommand.msg"
      "msg/GimbalValue.msg"
      "msg/BatteryCommand.msg"
    )

重新构建 interface：

    cd ~/communication
    source /opt/ros/<ROS_DISTRO>/setup.bash
    colcon build --packages-select interface
    source install/setup.bash

确认生成：

    ros2 interface show interface/msg/BatteryCommand

7.3 在 senddata.cpp 中包含消息头

    #include "interface/msg/battery_command.hpp"

7.4 定义串口载荷

串口载荷必须与下位机结构体逐字节一致：

    #pragma pack(push, 1)

    struct BatteryCommandPacket {
        float voltage_limit;
        uint8_t mode;
    };

    #pragma pack(pop)

增加编译期大小检查：

    static_assert(
        sizeof(BatteryCommandPacket) == 5,
        "BatteryCommandPacket wire size mismatch");

如果载荷有显式填充，必须把填充写入结构体，不能依赖编译器自动对齐。

7.5 注册 PacketTraits

命令号不能与现有命令重复：

    template <>
    struct RPL::Meta::PacketTraits<BatteryCommandPacket>
        : RPL::Meta::PacketTraitsBase<
              RPL::Meta::PacketTraits<BatteryCommandPacket>> {
        static constexpr uint16_t cmd = 0x0202;
        static constexpr size_t size = sizeof(BatteryCommandPacket);
    };

7.6 加入发送 Serializer

修改 getnode 中的 serializer_ 类型：

    RPL::Serializer<
        ControlCommandPacket,
        FireCommandPacket,
        BatteryCommandPacket> serializer_;

7.7 增加 Subscription 和回调

增加成员：

    rclcpp::Subscription<
        interface::msg::BatteryCommand>::SharedPtr battery_command_node_;

增加回调：

    void callback_battery_command(
        const interface::msg::BatteryCommand::SharedPtr command) {
        if (!command) {
            return;
        }

        BatteryCommandPacket packet{};
        packet.voltage_limit = command->voltage_limit;
        packet.mode = command->mode;

        std::lock_guard<std::mutex> lock(data_mutex_);
        latest_battery_packet_ = packet;
        battery_pending_ = true;
        ++battery_generation_;
    }

需要同步增加：

    BatteryCommandPacket latest_battery_packet_{};
    bool battery_pending_{false};
    uint64_t battery_generation_{0};

7.8 创建 Subscription

在 getnode 构造函数中创建：

    battery_command_node_ =
        this->create_subscription<
            interface::msg::BatteryCommand>(
                "battery_command",
                rclcpp::QoS(10),
                std::bind(
                    &getnode::callback_battery_command,
                    this,
                    std::placeholders::_1));

7.9 扩展发送调度

当前 send_packet() 只处理 control_pending_ 和 fire_pending_，必须加入
battery_pending_ 的快照、发送和清除逻辑，例如：

    if (send_battery &&
        send_packet(battery_snapshot)) {
        std::lock_guard<std::mutex> lock(data_mutex_);

        if (battery_generation_ == battery_generation) {
            battery_pending_ = false;
        }
    }

7.10 修改下位机接收

在下位机中增加相同载荷和命令号，并在接收命令表、帧长检查和命令分发
逻辑中登记新命令。下位机完成后，重新编译并烧录固件。

具体修改：

    1. 在 rpl_compat.h 中增加 packed 结构体和命令号。
    2. 在 serial.c 中定义目标结构体及 ready_flag。
    3. 在 serial.h 中 extern 声明目标结构体和 ready_flag。
    4. 在 packet_bindings[] 中增加：

       {
           新命令号,
           &目标结构体,
           sizeof(目标结构体),
           &ready_flag
       }

不需要新增专用 parse 函数。parse_packet_frame() 会根据命令号自动查找
对应绑定并复制数据。


8. 新增下位机 -> 上位机数据类型
-------------------------------

以下步骤实现一个新的接收类型，例如 BatteryStatus。

8.1 新增并注册 ROS 消息

创建：

    src/interface/msg/BatteryStatus.msg

内容示例：

    float32 voltage
    float32 current

加入 src/interface/CMakeLists.txt：

    rosidl_generate_interfaces(${PROJECT_NAME}
      "msg/Datainterface.msg"
      "msg/FireCommand.msg"
      "msg/GimbalValue.msg"
      "msg/BatteryStatus.msg"
    )

重新构建并 source：

    cd ~/communication
    colcon build --packages-select interface
    source install/setup.bash

8.2 在 senddata.cpp 中包含消息头

    #include "interface/msg/battery_status.hpp"

8.3 定义串口载荷

    #pragma pack(push, 1)

    struct BatteryStatusPacket {
        float voltage;
        float current;
    };

    #pragma pack(pop)

    static_assert(
        sizeof(BatteryStatusPacket) == 8,
        "BatteryStatusPacket wire size mismatch");

下位机中的字段顺序、类型、大小和字节序必须完全相同。

8.4 注册 PacketTraits

    template <>
    struct RPL::Meta::PacketTraits<BatteryStatusPacket>
        : RPL::Meta::PacketTraitsBase<
              RPL::Meta::PacketTraits<BatteryStatusPacket>> {
        static constexpr uint16_t cmd = 0x0301;
        static constexpr size_t size = sizeof(BatteryStatusPacket);
    };

命令号必须与下位机发送命令号一致。

8.5 加入接收 Parser

修改接收类型列表：

    RPL::Deserializer<
        GimbalValuePacket,
        BatteryStatusPacket> rx_deserializer_;

    RPL::Parser<
        GimbalValuePacket,
        BatteryStatusPacket> rx_parser_{rx_deserializer_};

8.6 增加 Publisher

增加成员：

    rclcpp::Publisher<
        interface::msg::BatteryStatus>::SharedPtr battery_status_pub_;

在 getnode 构造函数中创建：

    battery_status_pub_ =
        this->create_publisher<
            interface::msg::BatteryStatus>(
                "battery_status",
                rclcpp::QoS(10));

Publisher 必须在接收定时器开始运行前完成初始化。

8.7 扩展 rx_bindings

把数组长度从 1 改为 2，并增加 BatteryStatusPacket 条目：

    std::array<RxPacketBinding, 2> rx_bindings_{
        {
            {
                /* 原有 GimbalValuePacket 条目 */
            },
            {
                RPL::Meta::PacketTraits<
                    BatteryStatusPacket>::cmd,
                sizeof(BatteryStatusPacket),
                0U,
                [this](RxPacketBinding &binding) {
                    const uint32_t version =
                        rx_deserializer_.version<
                            BatteryStatusPacket>();

                    if (version == 0U ||
                        version == binding.last_version) {
                        return;
                    }

                    binding.last_version = version;

                    const BatteryStatusPacket packet =
                        rx_deserializer_.get<
                            BatteryStatusPacket>();

                    interface::msg::BatteryStatus message;
                    message.voltage = packet.voltage;
                    message.current = packet.current;

                    battery_status_pub_->publish(message);
                }
            }
        }
    };

每条 binding 包含：

    command_id
        与 PacketTraits 一致的命令号。

    payload_size
        串口载荷大小，便于交叉检查。

    last_version
        Deserializer 上次处理版本，用来避免重复发布。

    process
        将串口结构体转换成 ROS 消息并调用 Publisher 的 lambda。

8.8 修改下位机发送

下位机需要：

    1. 增加同布局的 packed 结构体。
    2. 增加发送命令号。
    3. 把 {命令号, sizeof(结构体)} 加入 g_packet_formats[]。
    4. 调用 send_packet(新命令号, &payload) 或封装专用发送函数。
    5. 在控制循环或任务中实际调用发送函数。

完成以上修改后，重新编译上位机和下位机。

注意：如果新 payload 超过当前帧缓冲区能容纳的大小，还必须增大
receive/serial.h 中的 RPL_FRAME_CAPACITY。当前 64 字节完整帧容量对应的
最大 payload 是 55 字节。


9. 修改已有数据类型
-------------------

给已有数据增加字段时，不能只修改 .msg。

必须同步检查：

    1. interface/msg 中对应 .msg。
    2. senddata.cpp 中对应串口载荷结构体。
    3. 对应的 static_assert 大小。
    4. PacketTraits::size 会随 sizeof 自动变化。
    5. ROS 消息到串口载荷的赋值代码。
    6. 串口载荷到 ROS 消息的赋值代码。
    7. 下位机对应结构体。
    8. 下位机 packet_bindings[] 中对应 payload_length。
    9. 下位机 g_packet_formats[] 中对应 payload_length。
    10. 下位机接收或发送缓冲区大小。

如果只改 .msg，不同步修改串口结构体，会出现字段丢失、帧长度错误、CRC
校验失败或内存越界。


10. 命令号管理
-------------

当前命令号：

    RPL_CMD_CONTROL       0x0200
    RPL_CMD_FIRE          0x0201
    RPL_CMD_GIMBAL_VALUE  0x0300

建议命令号分区：

    0x0200 - 0x02FF
        上位机 -> 下位机

    0x0300 - 0x03FF
        下位机 -> 上位机

新增命令时保持方向分区，方便调试，也能避免串口回显时把本机发送的数据
误认为下位机上传数据。

命令号必须同时修改：

    - 下位机 rpl_compat.h 中的宏
    - 下位机命令/载荷长度表
    - 上位机 PacketTraits::cmd


11. 常见问题
------------

11.1 ros2 run 找不到 senddata

确认已经构建并 source：

    cd ~/communication
    colcon build --packages-up-to senddata
    source /opt/ros/<ROS_DISTRO>/setup.bash
    source ~/communication/install/setup.bash

检查：

    ros2 pkg prefix senddata
    ros2 pkg executables senddata
    ls ~/communication/install/senddata/lib/senddata/

11.2 修改代码后运行结果没有变化

可能仍在运行旧进程或旧安装文件：

    ros2 node list
    ps -ef | grep -E 'senddata|li4_node'
    ros2 pkg prefix senddata

停止旧节点，重新 colcon build 并 source 后再启动。

11.3 收不到 /gimbal_value

    1. 确认串口设备路径正确。
    2. 确认两端均为 115200 8N1。
    3. 确认 TX/RX 交叉连接并共地。
    4. 确认下位机调用了 SendGimbalValue()。
    5. 确认下位机命令号为 0x0300。
    6. 确认 GimbalValuePacket 为 4 字节。
    7. 检查 RPL 帧头、长度、CRC8 和 CRC16。

11.4 能收到串口数据但不发布 ROS 话题

    1. 检查命令号是否一致。
    2. 检查载荷长度是否一致。
    3. 检查 PacketTraits::size 是否正确。
    4. 检查对应类型是否加入 Deserializer/Parser。
    5. 检查 rx_bindings 是否增加了处理条目。
    6. 检查 Publisher 是否已经创建。

11.5 修改 interface 后出现旧消息或旧类型

重新构建 interface，并确保 source 的是当前工作空间：

    cd ~/communication
    colcon build --packages-select interface
    source ~/communication/install/setup.bash

如果多个工作空间存在同名 interface，检查：

    ros2 pkg prefix interface

输出必须指向：

    ~/communication/install/interface

