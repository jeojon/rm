bool fire
