#include "rclcpp/rclcpp.hpp"
#include "interface/msg/datainterface.hpp"
#include <chrono>

using std::placeholders::_1;

class novalwriter : public rclcpp::Node
{
private:
  //声明一发布者
  rclcpp::Publisher<interface::msg::Datainterface>::SharedPtr pub_noval;
  //声明定时器
  rclcpp::TimerBase::SharedPtr timer_;
  


public:
   void publish_noval()
  {
    interface::msg::Datainterface angle_data;
    angle_data.angle_yaw = 0.5 * sin(rclcpp::Clock().now().seconds());
    angle_data.angle_pitch = 0.1 * sin(rclcpp::Clock().now().seconds());
    pub_noval->publish(angle_data);
  }
  novalwriter(std::string name) : Node(name)
  {
    RCLCPP_INFO(this->get_logger(), "Hello, this is a writer %s", name.c_str());
    //创建一个发布者
    pub_noval = this->create_publisher<interface::msg::Datainterface>(
        "angle_data", 10);
    timer_ = this->create_wall_timer(
      std::chrono::milliseconds(1000),
      [this]() {
        publish_noval();
      });
  }
  

}; 





int main(int argc,char ** argv){
   rclcpp::init(argc,argv);//
   auto node = std::make_shared<novalwriter>("li4");
   rclcpp::spin(node);
   rclcpp::shutdown();
   return 0;
}





