#include "rclcpp/rclcpp.hpp"
#include "interface/msg/datainterface.hpp"
#include "interface/msg/fire_command.hpp"
#include "interface/msg/gimbal_value.hpp"
#include "RPL.hpp"

#include <array>
#include <cerrno>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <functional>
#include <mutex>
#include <string>
#include <utility>

#include <fcntl.h>
#include <poll.h>
#include <termios.h>
#include <unistd.h>

static constexpr const char* SERIAL_DEVICE =
    "/dev/serial/by-id/usb-1a86_USB_Serial-if00-port0";

#pragma pack(push, 1)
// Upper computer -> lower computer.
struct ControlCommandPacket {
    float angle_yaw;
    float angle_pitch;
};

struct FireCommandPacket {
    bool fire;
};

// Lower computer -> upper computer.
struct GimbalValuePacket {
    float value;
};
#pragma pack(pop)

static_assert(
    sizeof(ControlCommandPacket) == 8,
    "ControlCommandPacket wire size mismatch");
static_assert(
    sizeof(FireCommandPacket) == 1,
    "FireCommandPacket wire size mismatch");
static_assert(
    sizeof(GimbalValuePacket) == 4,
    "GimbalValuePacket wire size mismatch");

template <>
struct RPL::Meta::PacketTraits<ControlCommandPacket>
    : RPL::Meta::PacketTraitsBase<
          RPL::Meta::PacketTraits<ControlCommandPacket>> {
    static constexpr uint16_t cmd = 0x0200;
    static constexpr size_t size = sizeof(ControlCommandPacket);
};

template <>
struct RPL::Meta::PacketTraits<FireCommandPacket>
    : RPL::Meta::PacketTraitsBase<
          RPL::Meta::PacketTraits<FireCommandPacket>> {
    static constexpr uint16_t cmd = 0x0201;
    static constexpr size_t size = sizeof(FireCommandPacket);
};

template <>
struct RPL::Meta::PacketTraits<GimbalValuePacket>
    : RPL::Meta::PacketTraitsBase<
          RPL::Meta::PacketTraits<GimbalValuePacket>> {
    static constexpr uint16_t cmd = 0x0300;
    static constexpr size_t size = sizeof(GimbalValuePacket);
};

/*
 * 打开并配置串口：
 * 115200、8 数据位、无校验、1 停止位、无流控、raw 模式。
 *
 * 成功返回文件描述符，失败返回 -1。
 */
static int serial_open_and_configure(const char *device) {
    int fd = ::open(
        device,
        O_RDWR | O_NOCTTY | O_NONBLOCK | O_CLOEXEC);

    if (fd < 0) {
        return -1;
    }

    termios tty{};

    if (::tcgetattr(fd, &tty) != 0) {
        ::close(fd);
        return -1;
    }

    // 禁止回车换行转换、回显、特殊控制字符处理等
    ::cfmakeraw(&tty);

    tty.c_cflag |= CLOCAL | CREAD;

    // 8 位数据
    tty.c_cflag &= ~CSIZE;
    tty.c_cflag |= CS8;

    // 无校验、1 位停止位
    tty.c_cflag &= ~PARENB;
    tty.c_cflag &= ~CSTOPB;

#ifdef CRTSCTS
    // 无硬件流控
    tty.c_cflag &= ~CRTSCTS;
#endif

    // 无软件流控
    tty.c_iflag &= ~(IXON | IXOFF | IXANY);

    tty.c_cc[VMIN] = 0;
    tty.c_cc[VTIME] = 0;

    if (::cfsetispeed(&tty, B115200) != 0 ||
        ::cfsetospeed(&tty, B115200) != 0 ||
        ::tcsetattr(fd, TCSANOW, &tty) != 0) {
        ::close(fd);
        return -1;
    }

    // 清除打开前可能存在的残留数据
    ::tcflush(fd, TCIOFLUSH);

    return fd;
}

/*
 * 指定长度的数据全部写入串口。
 */
static bool serial_send(
    int fd,
    const uint8_t *data,
    size_t size) {

    size_t written = 0;

    while (written < size) {
        const ssize_t result =
            ::write(fd, data + written, size - written);

        if (result > 0) {
            written += static_cast<size_t>(result);
            continue;
        }

        if (result == 0) {
            return false;
        }

        if (errno == EINTR) {
            continue;
        }

        if (errno == EAGAIN || errno == EWOULDBLOCK) {
            pollfd pfd{};
            pfd.fd = fd;
            pfd.events = POLLOUT;

            const int poll_result = ::poll(&pfd, 1, 100);

            if (poll_result > 0 &&
                (pfd.revents & POLLOUT) != 0) {
                continue;
            }

            if (poll_result < 0 && errno == EINTR) {
                continue;
            }
        }

        return false;
    }

    return true;
}

class getnode : public rclcpp::Node {
private:
    // 接收数据包绑定结构体，用于处理不同类型的数据包。
    struct RxPacketBinding {
        uint16_t command_id;
        size_t payload_size;
        uint32_t last_version{0};
        std::function<void(RxPacketBinding &)> process;
    };

    std::mutex data_mutex_;
    ControlCommandPacket latest_control_packet_{};
    FireCommandPacket latest_fire_packet_{};
    bool has_control_value_{false};
    bool has_fire_value_{false};
    bool control_pending_{false};
    bool fire_pending_{false};
    uint64_t control_generation_{0};
    uint64_t fire_generation_{0};

    RPL::Serializer<
        ControlCommandPacket,
        FireCommandPacket> serializer_;

    // 接收解析器和发送序列化器分别管理两个方向的数据。
    RPL::Deserializer<GimbalValuePacket> rx_deserializer_;
    RPL::Parser<GimbalValuePacket> rx_parser_{rx_deserializer_};
    //根据命令id解析下位机数据
    std::array<RxPacketBinding, 1> rx_bindings_{
        {
            {
                RPL::Meta::PacketTraits<GimbalValuePacket>::cmd,
                sizeof(GimbalValuePacket),
                0U,
                [this](RxPacketBinding &binding) {
                    const uint32_t version =
                        rx_deserializer_.version<GimbalValuePacket>();

                    if (version == 0U ||
                        version == binding.last_version) {
                        return;
                    }

                    binding.last_version = version;

                    const GimbalValuePacket packet =
                        rx_deserializer_.get<GimbalValuePacket>();

                    interface::msg::GimbalValue message;
                    message.value = packet.value;
                    gimbal_value_pub_->publish(message);
                }
            }
        }
    };

    rclcpp::TimerBase::SharedPtr rx_timer_;
    rclcpp::TimerBase::SharedPtr tx_timer_;

    int serial_fd_{-1};

    rclcpp::Subscription<
        interface::msg::Datainterface>::SharedPtr angle_node_;
    rclcpp::Subscription<
        interface::msg::FireCommand>::SharedPtr fire_command_node_;
    rclcpp::Publisher<
        interface::msg::GimbalValue>::SharedPtr gimbal_value_pub_;

    void callback_control_command(
        const interface::msg::Datainterface::SharedPtr angle_data) {

        ControlCommandPacket packet{};
        packet.angle_yaw = angle_data->angle_yaw;
        packet.angle_pitch = angle_data->angle_pitch;

        {
            std::lock_guard<std::mutex> lock(data_mutex_);

            const bool changed =
                !has_control_value_ ||
                packet.angle_yaw != latest_control_packet_.angle_yaw ||
                packet.angle_pitch != latest_control_packet_.angle_pitch;

            latest_control_packet_ = packet;
            has_control_value_ = true;

            if (changed) {
                control_pending_ = true;
                ++control_generation_;
            }
        }

        RCLCPP_INFO(
            this->get_logger(),
            "Received angle data: yaw=%.3f, pitch=%.3f",
            packet.angle_yaw,
            packet.angle_pitch);
    }

    void callback_fire_command(
        const interface::msg::FireCommand::SharedPtr command) {

        if (!command) {
            return;
        }

        {
            std::lock_guard<std::mutex> lock(data_mutex_);

            const bool changed =
                !has_fire_value_ ||
                latest_fire_packet_.fire != command->fire;

            latest_fire_packet_.fire = command->fire;
            has_fire_value_ = true;

            if (changed) {
                fire_pending_ = true;
                ++fire_generation_;
            }
        }

        RCLCPP_INFO(
            this->get_logger(),
            "Received fire command: fire=%s",
            command->fire ? "true" : "false");
    }

    void process_received_packets() {
        for (auto &binding : rx_bindings_) {
            binding.process(binding);
        }
    }

    void receive_packets() {
        if (serial_fd_ < 0) {
            return;
        }

        std::array<uint8_t, 256> buffer{};

        for (;;) {
            // 从串口读取数据。
            const ssize_t result =
                ::read(
                    serial_fd_,
                    buffer.data(),
                    buffer.size());

            if (result > 0) {
                // 将接收到的数据推送到解析器进行处理。
                auto parse_result = rx_parser_.push_data(
                    buffer.data(),
                    static_cast<size_t>(result));

                if (!parse_result) {
                    RCLCPP_ERROR_THROTTLE(
                        this->get_logger(),
                        *this->get_clock(),
                        2000,
                        "RPL receive failed: %s",
                        parse_result.error().message.c_str());
                    rx_parser_.clear_buffer();
                }

                continue;
            }

            if (result == 0) {
                break;
            }

            if (errno == EINTR) {
                continue;
            }

            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                break;
            }

            RCLCPP_ERROR_THROTTLE(
                this->get_logger(),
                *this->get_clock(),
                2000,
                "Serial receive failed: %s",
                std::strerror(errno));
            break;
        }

        process_received_packets();
    }

    template <typename Packet>
        requires RPL::Serializable<
            Packet,
            ControlCommandPacket,
            FireCommandPacket>
    bool send_packet(const Packet &packet) {
        constexpr size_t frame_capacity =
            RPL::Serializer<
                ControlCommandPacket,
                FireCommandPacket>::frame_size<Packet>();

        std::array<uint8_t, frame_capacity> frame{};

        auto result =
            serializer_.serialize(
                frame.data(),
                frame.size(),
                packet);

        if (!result) {
            RCLCPP_ERROR(
                this->get_logger(),
                "RPL serialize failed: %s",
                result.error().message.c_str());
            return false;
        }

        if (!serial_send(
                serial_fd_,
                frame.data(),
                *result)) {
            RCLCPP_ERROR_THROTTLE(
                this->get_logger(),
                *this->get_clock(),
                2000,
                "Serial send failed: %s",
                std::strerror(errno));
            return false;
        }

        return true;
    }

    void send_packet() {
        if (serial_fd_ < 0) {
            RCLCPP_ERROR_THROTTLE(
                this->get_logger(),
                *this->get_clock(),
                2000,
                "Serial port is not open");
            return;
        }

        ControlCommandPacket control_snapshot{};
        FireCommandPacket fire_snapshot{};
        bool send_control;
        bool send_fire;
        uint64_t control_generation;
        uint64_t fire_generation;

        {
            std::lock_guard<std::mutex> lock(data_mutex_);
            send_control = control_pending_;
            send_fire = fire_pending_;
            control_snapshot = latest_control_packet_;
            fire_snapshot = latest_fire_packet_;
            control_generation = control_generation_;
            fire_generation = fire_generation_;
        }

        if (send_control &&
            send_packet(control_snapshot)) {
            std::lock_guard<std::mutex> lock(data_mutex_);

            // 如果发送期间又有新角度数据，保留新的待发送状态。
            if (control_generation_ == control_generation) {
                control_pending_ = false;
            }
        }

        if (send_fire &&
            send_packet(fire_snapshot)) {
            std::lock_guard<std::mutex> lock(data_mutex_);

            // 如果发送期间又收到新命令，不清除新的待发送状态。
            if (fire_generation_ == fire_generation) {
                fire_pending_ = false;
            }
        }
    }

public:
    explicit getnode(const std::string &name)
        : Node(name) {

        serial_fd_ = serial_open_and_configure(SERIAL_DEVICE);

        if (serial_fd_ < 0) {
            RCLCPP_ERROR(
                this->get_logger(),
                "Open %s failed: %s",
                SERIAL_DEVICE,
                std::strerror(errno));
        } else {
            RCLCPP_INFO(
                this->get_logger(),
                "Serial %s opened: 115200 8N1",
                SERIAL_DEVICE);
        }

        angle_node_ =
            this->create_subscription<
                interface::msg::Datainterface>(
                    "angle_data",
                    rclcpp::QoS(10),
                    std::bind(
                        &getnode::callback_control_command,
                        this,
                        std::placeholders::_1));

        fire_command_node_ =
            this->create_subscription<
                interface::msg::FireCommand>(
                    "fire_command",
                    rclcpp::QoS(10),
                    std::bind(
                        &getnode::callback_fire_command,
                        this,
                        std::placeholders::_1));

        gimbal_value_pub_ =
            this->create_publisher<interface::msg::GimbalValue>(
                "gimbal_value",
                rclcpp::QoS(10));

        rx_timer_ = this->create_wall_timer(
            std::chrono::milliseconds(1),
            [this]() {
                receive_packets();
            });

        tx_timer_ = this->create_wall_timer(
            std::chrono::milliseconds(10),
            [this]() {
                send_packet();
            });
    }

    ~getnode() noexcept override {
        if (serial_fd_ >= 0) {
            ::close(serial_fd_);
            serial_fd_ = -1;
        }
    }
};

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);

    auto node =
        std::make_shared<getnode>("angle_getnode");

    rclcpp::spin(node);

    rclcpp::shutdown();
    return 0;
}
